module co.edu.uniquindio.prestamo.prestamo {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires org.apache.pdfbox;

    opens co.edu.uniquindio.prestamo.prestamo to javafx.fxml;
    exports co.edu.uniquindio.prestamo.prestamo;
    opens co.edu.uniquindio.prestamo.prestamo.viewController;
    exports co.edu.uniquindio.prestamo.prestamo.viewController;
    opens co.edu.uniquindio.prestamo.prestamo.controller;
    exports co.edu.uniquindio.prestamo.prestamo.controller;
}