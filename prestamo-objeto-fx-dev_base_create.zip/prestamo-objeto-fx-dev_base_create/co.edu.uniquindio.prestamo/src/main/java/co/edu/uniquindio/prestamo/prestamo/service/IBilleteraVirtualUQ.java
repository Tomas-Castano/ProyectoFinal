package co.edu.uniquindio.prestamo.prestamo.service;

import co.edu.uniquindio.prestamo.prestamo.model.*;

public interface IBilleteraVirtualUQ {
    Usuario verificarCredenciales(String nombre, String contraseña);
    void registrarTransaccion(Transaccion transaccion);
    void agregarCuenta(Cliente cliente, Cuenta cuentaNueva);
    void eliminarCuenta(Cliente cliente, Cuenta cuenta);
    void actualizarCuenta(Cliente cliente, Cuenta cuentaModificada);
    void actualizarDatosPerfil(Cliente cliente, String nombre, String apellido, String correo, String telefono);
    void realizarTransaccion(Transaccion transaccion);

    void crearCategoria(Cliente cliente, Categoria categoriaNueva);
    void actualizarCategoria(Categoria seleccionada, String nombre, String descripcion);
    void eliminarCategoria(Categoria seleccionada);
}
