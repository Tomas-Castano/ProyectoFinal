package co.edu.uniquindio.prestamo.prestamo.model;


import java.util.ArrayList;
import java.util.List;

public class Cliente extends Usuario {
    private String email;
    private String telefonoFijo;
    private String telefonoCelular;
    private String direccion;
    private List<Cuenta> listaCuentas = new ArrayList<>();
    private List<Presupuesto> listaPresupuestos = new ArrayList<>();
    private List<Categoria> listaCategorias = new ArrayList<>();

    public Cliente(String email, String telefonoFijo, String telefonoCelular, String direccion) {
    }

    public Cliente(String nombre, String apellido, String cedula, int edad, String email, String telefonoFijo, String telefonoCelular, String direccion, String contraseña) {
        super(nombre, apellido, cedula, edad, contraseña);
        this.email = email;
        this.telefonoFijo = telefonoFijo;
        this.telefonoCelular = telefonoCelular;
        this.direccion = direccion;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefonoFijo() {
        return telefonoFijo;
    }

    public void setTelefonoFijo(String telefonoFijo) {
        this.telefonoFijo = telefonoFijo;
    }

    public String getTelefonoCelular() {
        return telefonoCelular;
    }

    public void setTelefonoCelular(String telefonoCelular) {
        this.telefonoCelular = telefonoCelular;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public List<Cuenta> getListaCuentas() {
        return listaCuentas;
    }

    public void setListaCuentas(List<Cuenta> listaCuentas) {
        this.listaCuentas = listaCuentas;
    }

    public void agregarCuenta(Cuenta cuenta) {
        listaCuentas.add(cuenta);
    }

    public List<Presupuesto> getListaPresupuestos() {
        return listaPresupuestos;
    }

    public void setListaPresupuestos(List<Presupuesto> listaPresupuestos) {
        this.listaPresupuestos = listaPresupuestos;
    }

    public List<Categoria> getListaCategorias() {
        return listaCategorias;
    }

    public void setListaCategorias(List<Categoria> listaCategorias) {
        this.listaCategorias = listaCategorias;
    }

    public void agregarPresupuesto(Presupuesto presupuesto) {
        listaPresupuestos.add(presupuesto);
    }

    @Override
    public String toString() {
        return super.getNombre() + " " + super.getApellido() + " - Cédula: " + super.getCedula();
    }

    public void agregarCategoria(Categoria categoriaComidaJuan) {
        listaCategorias.add(categoriaComidaJuan);
    }
}
