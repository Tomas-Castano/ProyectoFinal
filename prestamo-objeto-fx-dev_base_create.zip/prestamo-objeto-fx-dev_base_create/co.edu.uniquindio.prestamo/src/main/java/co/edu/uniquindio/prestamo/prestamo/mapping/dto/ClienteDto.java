package co.edu.uniquindio.prestamo.prestamo.mapping.dto;

public record ClienteDto(
        String nombre,
        String apellido,
        String cedula,
        String email,
       String direccion
) {
}
