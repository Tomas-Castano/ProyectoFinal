package co.edu.uniquindio.prestamo.prestamo.viewController;

import co.edu.uniquindio.prestamo.prestamo.controller.CategoriaClienteController;
import co.edu.uniquindio.prestamo.prestamo.factory.ModelFactory;
import co.edu.uniquindio.prestamo.prestamo.model.Categoria;
import co.edu.uniquindio.prestamo.prestamo.model.Cliente;
import javafx.beans.property.SimpleStringProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class CategoriaClienteViewController {
    private CategoriaClienteController categoriaController = new CategoriaClienteController();

    @FXML
    private Button btnActualizarCategoria;

    @FXML
    private Button btnCrearCategoria;

    @FXML
    private Button btnEliminarCategoria;

    @FXML
    private TableView<Categoria> tableViewCategoria;

    @FXML
    private TableColumn<Categoria, String> tbColumnDescripcion;

    @FXML
    private TableColumn<Categoria, String> tbColumnId;

    @FXML
    private TableColumn<Categoria, String> tbColumnNombre;

    @FXML
    private TableColumn<Categoria, String> tbColumnPresupuestosAsociados;

    @FXML
    private TextArea txtDescripcion;

    @FXML
    private TextField txtNombre;

    @FXML
    public void initialize() {
        Cliente cliente = (Cliente) ModelFactory.getInstancia().getUsuarioActual();
        initDataBinding(cliente);
    }

    @FXML
    void onActualizarCategoria(ActionEvent event) {
        actualizarCategoria();
    }

    @FXML
    void onCrearCategoria(ActionEvent event) {
        crearCategoria();
    }

    @FXML
    void onEliminarCategoria(ActionEvent event) {
        eliminarCategoria();
    }

    private void initDataBinding(Cliente cliente) {
        tbColumnNombre.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getNombreCategoria()));
        tbColumnId.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getIdCategoria()));
        tbColumnDescripcion.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getDescripcionCategoria()));
        tbColumnPresupuestosAsociados.setCellValueFactory(cellData ->
                new SimpleStringProperty(String.valueOf(cellData.getValue().getListaPresupuestosAsociados().size())));

        actualizarTabla(cliente);
    }

    private void crearCategoria() {
        String nombre = txtNombre.getText();
        String descripcion = txtDescripcion.getText();
        Cliente cliente = (Cliente) ModelFactory.getInstancia().getUsuarioActual();

        if (nombre.isEmpty()) {
            mostrarMensaje("Error", "Campo obligatorio", "El nombre de la categoría es obligatorio", Alert.AlertType.ERROR);
            return;
        }

        try {
            Categoria nueva = new Categoria(UUID.randomUUID().toString(), nombre, descripcion);
            categoriaController.crearCategoria(cliente, nueva);
            mostrarMensaje("Éxito", "Categoría creada", "Se creó correctamente", Alert.AlertType.INFORMATION);
            limpiarCampos();
            actualizarTabla(cliente);
        } catch (IllegalArgumentException e) {
            mostrarMensaje("Error", "Categoría duplicada", e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void actualizarCategoria() {
        Categoria seleccionada = tableViewCategoria.getSelectionModel().getSelectedItem();
        if (seleccionada == null) {
            mostrarMensaje("Error", "Sin selección", "Seleccione una categoría", Alert.AlertType.WARNING);
            return;
        }

        String nombre = txtNombre.getText();
        String descripcion = txtDescripcion.getText();

        if (nombre.isEmpty()) {
            mostrarMensaje("Error", "Campo obligatorio", "El nombre no puede estar vacío", Alert.AlertType.ERROR);
            return;
        }

        Cliente cliente = (Cliente) ModelFactory.getInstancia().getUsuarioActual();
        categoriaController.actualizarCategoria(seleccionada, nombre, descripcion);
        mostrarMensaje("Éxito", "Actualizada", "Categoría actualizada correctamente", Alert.AlertType.INFORMATION);
        limpiarCampos();
        actualizarTabla(cliente);
    }

    private void eliminarCategoria() {
        Categoria seleccionada = tableViewCategoria.getSelectionModel().getSelectedItem();
        if (seleccionada == null) {
            mostrarMensaje("Error", "Sin selección", "Seleccione una categoría", Alert.AlertType.WARNING);
            return;
        }

        Cliente cliente = (Cliente) ModelFactory.getInstancia().getUsuarioActual();
        categoriaController.eliminarCategoria(seleccionada);
        mostrarMensaje("Éxito", "Eliminada", "Categoría eliminada correctamente", Alert.AlertType.INFORMATION);
        actualizarTabla(cliente);
    }

    private void actualizarTabla(Cliente cliente) {
        tableViewCategoria.getItems().setAll(cliente.getListaCategorias());
    }

    private void limpiarCampos() {
        txtNombre.clear();
        txtDescripcion.clear();
    }

    private void mostrarMensaje(String titulo, String header, String contenido, Alert.AlertType tipo) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(header);
        alert.setContentText(contenido);
        alert.showAndWait();
    }
}