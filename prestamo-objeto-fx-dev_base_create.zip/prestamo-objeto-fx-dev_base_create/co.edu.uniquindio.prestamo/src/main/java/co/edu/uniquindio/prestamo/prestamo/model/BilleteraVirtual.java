package co.edu.uniquindio.prestamo.prestamo.model;

import co.edu.uniquindio.prestamo.prestamo.service.IBilleteraVirtualUQ;
import co.edu.uniquindio.prestamo.prestamo.strategy.EstrategiaComision;
import co.edu.uniquindio.prestamo.prestamo.utils.TipoTransaccion;

import java.util.ArrayList;
import java.util.List;

public class BilleteraVirtual implements IBilleteraVirtualUQ {
    List<Cliente> listaClientes = new ArrayList<>();
    List<Empleado> listaEmpleados = new ArrayList<>();
    List<Presupuesto> listaPresupuestos = new ArrayList<>();
    List<Categoria> listaCategorias = new ArrayList<>();
    List<Transaccion> listaTransacciones = new ArrayList<>();


    public BilleteraVirtual() {
    }

    public List<Cliente> getListaClientes() {
        return listaClientes;
    }

    public void setListaClientes(List<Cliente> listaClientes) {
        this.listaClientes = listaClientes;
    }

    public List<Empleado> getListaEmpleados() {
        return listaEmpleados;
    }

    public void setListaEmpleados(List<Empleado> listaEmpleados) {
        this.listaEmpleados = listaEmpleados;
    }

    public List<Presupuesto> getListaPresupuestos() {
        return listaPresupuestos;
    }

    public void setListaPresupuestos(List<Presupuesto> listaPresupuestos) {
        this.listaPresupuestos = listaPresupuestos;
    }

    public List<Categoria> getListaCategorias() {
        return listaCategorias;
    }

    public void setListaCategorias(List<Categoria> listaCategorias) {
        this.listaCategorias = listaCategorias;
    }

    public List<Transaccion> getListaTransacciones() {
        return listaTransacciones;
    }

    public void setListaTransacciones(List<Transaccion> listaTransacciones) {
        this.listaTransacciones = listaTransacciones;
    }

    @Override
    public Usuario verificarCredenciales(String nombre, String contraseña) {
        for (Cliente cliente : listaClientes) {
            if (cliente.getNombre().equals(nombre) && cliente.getContraseña().equals(contraseña)) {
                return cliente;
            }
        }

        for (Empleado empleado : listaEmpleados) {
            if (empleado.getNombre().equals(nombre) && empleado.getContraseña().equals(contraseña)) {
                return empleado;
            }
        }

        return null;
    }

    @Override
    public void registrarTransaccion(Transaccion transaccion) {
        Cuenta origen = transaccion.getCuentaOrigen();
        Cuenta destino = transaccion.getCuentaDestino();
        double monto = transaccion.getMonto();
        TipoTransaccion tipo = transaccion.getTipoTransaccion();

        switch (tipo) {
            case TRANSFERENCIA:
                if (origen.getSaldo() < monto)
                    throw new IllegalArgumentException("Saldo insuficiente.");
                origen.setSaldo(origen.getSaldo() - monto);
                destino.setSaldo(destino.getSaldo() + monto);
                break;

            case DEPOSITO:
                origen.setSaldo(origen.getSaldo() + monto);
                break;

            case RETIRO:
                if (origen.getSaldo() < monto)
                    throw new IllegalArgumentException("Saldo insuficiente.");
                origen.setSaldo(origen.getSaldo() - monto);
                break;
        }

        listaTransacciones.add(transaccion);
    }

    @Override
    public void agregarCuenta(Cliente cliente, Cuenta cuentaNueva) {
        for (Cuenta cuenta : cliente.getListaCuentas()) {
            if (cuenta.getIdCuenta().equals(cuentaNueva.getIdCuenta())) {
                throw new IllegalArgumentException("Ya existe una cuenta con ese ID.");
            }
        }

        cliente.getListaCuentas().add(cuentaNueva);
    }

    @Override
    public void eliminarCuenta(Cliente cliente, Cuenta cuenta) {
        cliente.getListaCuentas().remove(cuenta);
    }

    @Override
    public void actualizarCuenta(Cliente cliente, Cuenta cuentaModificada) {
        for (int i = 0; i < cliente.getListaCuentas().size(); i++) {
            Cuenta actual = cliente.getListaCuentas().get(i);
            if (actual.getIdCuenta().equals(cuentaModificada.getIdCuenta())) {
                actual.setNombreBanco(cuentaModificada.getNombreBanco());
                actual.setTipoCuenta(cuentaModificada.getTipoCuenta());
                break;
            }
        }
    }

    @Override
    public void actualizarDatosPerfil(Cliente cliente, String nombre, String apellido, String correo, String telefono) {
        cliente.setNombre(nombre);
        cliente.setApellido(apellido);
        cliente.setEmail(correo);
        cliente.setTelefonoCelular(telefono);
    }

    @Override
    public void realizarTransaccion(Transaccion transaccion) {
        Cuenta origen = transaccion.getCuentaOrigen();
        Cuenta destino = transaccion.getCuentaDestino();
        double monto = transaccion.getMonto();
        EstrategiaComision estrategia = transaccion.getEstrategia();

        double comision = estrategia.calcularComision(transaccion);
        double total = monto + comision;

        try {
            origen.transferir(total, destino);
        } catch (UnsupportedOperationException | IllegalArgumentException e) {
            throw new IllegalArgumentException("No se pudo realizar la transacción: " + e.getMessage());
        }

        listaTransacciones.add(transaccion);
    }

    @Override
    public void crearCategoria(Cliente clienteLogueado, Categoria nuevaCategoria) {
        for (Categoria categoriaExistente : clienteLogueado.getListaCategorias()) {
            if (categoriaExistente.getIdCategoria().equals(nuevaCategoria.getIdCategoria())) {
                throw new IllegalArgumentException("Ya existe una categoría con ese ID.");
            }
        }
        clienteLogueado.getListaCategorias().add(nuevaCategoria);
    }

    @Override
    public void actualizarCategoria(Categoria seleccionada, String nombre, String descripcion) {
        seleccionada.setNombreCategoria(nombre);
        seleccionada.setDescripcionCategoria(descripcion);
    }

    @Override
    public void eliminarCategoria(Categoria seleccionada) {
        listaCategorias.remove(seleccionada);
    }
}
