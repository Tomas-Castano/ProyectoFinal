package co.edu.uniquindio.prestamo.prestamo.utils;

public enum TipoTransaccion {
    DEPOSITO,
    RETIRO,
    TRANSFERENCIA
}
