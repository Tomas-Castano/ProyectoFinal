package co.edu.uniquindio.prestamo.prestamo.adapter;

import co.edu.uniquindio.prestamo.prestamo.model.Transaccion;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

import java.io.File;
import java.util.List;

public class PdfExportadorAdapter implements Exportador {
    @Override
    public void exportar(List<Transaccion> transacciones, File destino) throws Exception {
        try (PDDocument document = new PDDocument()) {
            PDPage page = new PDPage(PDRectangle.LETTER);
            document.addPage(page);

            PDPageContentStream content = new PDPageContentStream(document, page);
            content.setFont(PDType1Font.HELVETICA, 12);
            content.beginText();
            content.setLeading(14.5f);
            content.newLineAtOffset(50, 700);

            content.showText("Reporte de Transacciones");
            content.newLine();
            content.newLine();

            for (Transaccion t : transacciones) {
                content.showText("Fecha: " + t.getFecha() + ", Monto: $" + t.getMonto() + ", Tipo: " + t.getTipoTransaccion());
                content.newLine();
                content.showText("Origen: " + t.getCuentaOrigen().getNumeroCuenta() + ", Destino: " +
                        (t.getCuentaDestino() != null ? t.getCuentaDestino().getNumeroCuenta() : "N/A"));
                content.newLine();
                content.showText("Descripción: " + t.getDescripcion());
                content.newLine();
                content.newLine();
            }

            content.endText();
            content.close();

            document.save(destino);
        }
    }
}
