package co.edu.uniquindio.prestamo.prestamo.viewController;

import co.edu.uniquindio.prestamo.prestamo.factory.ModelFactory;
import co.edu.uniquindio.prestamo.prestamo.model.*;
import javafx.fxml.FXML;
import javafx.scene.chart.*;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class EstadisticasViewController {

    @FXML
    private BarChart<String, Number> barChartGastosComunes;

    @FXML
    private BarChart<String, Number> barChartUsuariosTransacciones;

    @FXML
    private CategoryAxis categoryAxisCuentas;

    @FXML
    private CategoryAxis categoryAxisPresupuestos;

    @FXML
    private CategoryAxis categoryAxisUsuarios;

    @FXML
    private NumberAxis numberAxisCantidadTransacciones;

    @FXML
    private NumberAxis numberAxisMontoGastado;

    @FXML
    private NumberAxis numberAxisSaldo;

    @FXML
    private ScatterChart<String, Number> scatterChartSaldos;

    @FXML
    public void initialize() {
        cargarGraficoGastosComunes();
        cargarGraficoUsuariosConMasTransacciones();
        cargarGraficoSaldos();
    }

    private void cargarGraficoGastosComunes() {
        BilleteraVirtual sistema = ModelFactory.getInstancia().getBilleteraVirtual();
        Map<String, Set<String>> clientesPorCategoria = new HashMap<>();

        for (Cliente cliente : sistema.getListaClientes()) {
            String idCliente = cliente.getCedula(); // o cualquier identificador único

            for (Presupuesto presupuesto : cliente.getListaPresupuestos()) {
                Categoria categoria = presupuesto.getCategoriaAsociada();
                if (categoria != null) {
                    String nombreCategoria = categoria.getNombreCategoria().trim().toLowerCase();
                    clientesPorCategoria
                            .computeIfAbsent(nombreCategoria, k -> new HashSet<>())
                            .add(idCliente);
                }
            }
        }

        XYChart.Series<String, Number> serie = new XYChart.Series<>();
        serie.setName("Usuarios por categoría");

        for (Map.Entry<String, Set<String>> entry : clientesPorCategoria.entrySet()) {
            int cantidadUsuarios = entry.getValue().size();
            serie.getData().add(new XYChart.Data<>(entry.getKey(), cantidadUsuarios));
        }

        barChartGastosComunes.getData().clear();
        barChartGastosComunes.getData().add(serie);
    }

    private void cargarGraficoUsuariosConMasTransacciones() {
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Transacciones por Usuario");

        Map<Cliente, Integer> conteoTransacciones = new HashMap<>();

        for (Transaccion transaccion : ModelFactory.getInstancia().getBilleteraVirtual().getListaTransacciones()) {
            Cuenta origen = transaccion.getCuentaOrigen();
            Cuenta destino = transaccion.getCuentaDestino();

            Cliente clienteOrigen = encontrarClientePorCuenta(origen);
            if (clienteOrigen != null) {
                conteoTransacciones.put(clienteOrigen, conteoTransacciones.getOrDefault(clienteOrigen, 0) + 1);
            }

            Cliente clienteDestino = encontrarClientePorCuenta(destino);
            if (clienteDestino != null && clienteDestino != clienteOrigen) {
                conteoTransacciones.put(clienteDestino, conteoTransacciones.getOrDefault(clienteDestino, 0) + 1);
            }
        }

        for (Map.Entry<Cliente, Integer> entry : conteoTransacciones.entrySet()) {
            int transacciones = entry.getValue();
            series.getData().add(new XYChart.Data<>(entry.getKey().getNombre(), transacciones));
        }

        barChartUsuariosTransacciones.getData().clear();
        barChartUsuariosTransacciones.getData().add(series);
    }

    private Cliente encontrarClientePorCuenta(Cuenta cuenta) {
        for (Cliente cliente : ModelFactory.getInstancia().getBilleteraVirtual().getListaClientes()) {
            if (cliente.getListaCuentas().contains(cuenta)) {
                return cliente;
            }
        }
        return null;
    }

    private void cargarGraficoSaldos() {
        BilleteraVirtual sistema = ModelFactory.getInstancia().getBilleteraVirtual();

        XYChart.Series<String, Number> serie = new XYChart.Series<>();
        serie.setName("Saldo por cuenta");

        for (Cliente cliente : sistema.getListaClientes()) {
            for (Cuenta cuenta : cliente.getListaCuentas()) {
                String label = cliente.getNombre() + " - " + cuenta.getNombreBanco();
                serie.getData().add(new XYChart.Data<>(label, cuenta.getSaldo()));
            }
        }

        scatterChartSaldos.getData().clear();
        scatterChartSaldos.getData().add(serie);
    }

    public void actualizarEstadisticas() {
        cargarGraficoGastosComunes();
        cargarGraficoUsuariosConMasTransacciones();
        cargarGraficoSaldos();
    }
}
