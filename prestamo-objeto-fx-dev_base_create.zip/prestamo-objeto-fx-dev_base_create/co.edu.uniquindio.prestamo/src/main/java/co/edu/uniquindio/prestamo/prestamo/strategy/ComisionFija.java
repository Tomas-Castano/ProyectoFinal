package co.edu.uniquindio.prestamo.prestamo.strategy;

import co.edu.uniquindio.prestamo.prestamo.model.Transaccion;

public class ComisionFija implements EstrategiaComision{
    @Override
    public double calcularComision(Transaccion transaccion) {
        return 500;
    }
}
