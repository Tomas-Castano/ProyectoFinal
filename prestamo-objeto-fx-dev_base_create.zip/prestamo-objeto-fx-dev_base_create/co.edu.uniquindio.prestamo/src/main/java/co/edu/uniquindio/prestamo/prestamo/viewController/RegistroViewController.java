package co.edu.uniquindio.prestamo.prestamo.viewController;

import co.edu.uniquindio.prestamo.prestamo.factory.ModelFactory;
import co.edu.uniquindio.prestamo.prestamo.model.Cliente;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;

public class RegistroViewController {

    @FXML
    private AnchorPane APcontenedorPrincipal;

    @FXML
    private Button btnIniciarSesion;

    @FXML
    private Button btnRegistrarse;

    @FXML
    private TextField txtApellido;

    @FXML
    private TextField txtCedula;

    @FXML
    private TextField txtContraseña;

    @FXML
    private TextField txtDireccion;

    @FXML
    private TextField txtEmail;

    @FXML
    private TextField txtEdad;

    @FXML
    private TextField txtNombre;

    @FXML
    private TextField txtTelefonoCelular;

    @FXML
    void onIniciarSesion(ActionEvent event) {
        CargarVistaIniciarSesion();
    }

    @FXML
    void onRegistrarse(ActionEvent event) {
        registrarse();
    }

    private void CargarVistaIniciarSesion() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/co/edu/uniquindio/prestamo/prestamo/Login.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle("Iniciar Sesión");
            stage.setScene(new Scene(root));
            stage.show();

            // Cerrar la ventana actual (registro)
            Stage ventanaActual = (Stage) btnIniciarSesion.getScene().getWindow();
            ventanaActual.close();

        } catch (IOException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudo cargar la vista de login", e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void registrarse() {
        String nombre = txtNombre.getText();
        String apellido = txtApellido.getText();
        String cedula = txtCedula.getText();
        String edadTexto = txtEdad.getText();
        String email = txtEmail.getText();
        String direccion = txtDireccion.getText();
        String telefonoCelular = txtTelefonoCelular.getText();
        String contraseña = txtContraseña.getText();

        if (nombre.isEmpty() || apellido.isEmpty() || cedula.isEmpty() || edadTexto.isEmpty()
                || email.isEmpty() || direccion.isEmpty() || telefonoCelular.isEmpty() || contraseña.isEmpty()) {
            mostrarMensaje("Error", "Campos vacíos", "Todos los campos deben estar llenos", Alert.AlertType.ERROR);
            return;
        }

        int edad;
        try {
            edad = Integer.parseInt(edadTexto);
        } catch (NumberFormatException e) {
            mostrarMensaje("Error", "Edad inválida", "La edad debe ser un número", Alert.AlertType.ERROR);
            return;
        }

        for (Cliente cliente : ModelFactory.getInstancia().getListaClientes()) {
            if (cliente.getCedula().equals(cedula)) {
                mostrarMensaje("Error", "Cliente existente", "Ya existe un cliente con esta cédula", Alert.AlertType.ERROR);
                return;
            }
        }

        Cliente nuevoCliente = new Cliente(nombre, apellido, cedula, edad, email, null, null, direccion, contraseña);
        nuevoCliente.setEmail(email);
        nuevoCliente.setDireccion(direccion);
        nuevoCliente.setTelefonoCelular(telefonoCelular);

        ModelFactory.getInstancia().getListaClientes().add(nuevoCliente);

        mostrarMensaje("Éxito", "Cliente registrado", "Ahora puedes iniciar sesión", Alert.AlertType.INFORMATION);

        limpiarCampos();
    }

    private void mostrarMensaje(String titulo, String header, String contenido, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(titulo);
        alert.setHeaderText(header);
        alert.setContentText(contenido);
        alert.showAndWait();
    }

    private void limpiarCampos() {
        txtNombre.clear();
        txtApellido.clear();
        txtCedula.clear();
        txtContraseña.clear();
        txtDireccion.clear();
        txtEmail.clear();
        txtTelefonoCelular.clear();
        txtEdad.clear();
    }
}