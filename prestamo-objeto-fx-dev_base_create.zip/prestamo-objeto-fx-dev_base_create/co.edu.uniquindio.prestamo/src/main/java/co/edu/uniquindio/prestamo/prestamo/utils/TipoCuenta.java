package co.edu.uniquindio.prestamo.prestamo.utils;

public enum TipoCuenta {
    CORRIENTE,
    AHORRO
}
