package co.edu.uniquindio.prestamo.prestamo.model;

public class Empleado extends Usuario {

    public Empleado() {
    }

    public Empleado(String nombre, String apellido, String cedula, int edad, String contraseña) {
        super(nombre, apellido, cedula, edad, contraseña);
    }

    @Override
    public String toString() {
        return super.getNombre() + " " + super.getApellido() + " (Empleado)";
    }
}
