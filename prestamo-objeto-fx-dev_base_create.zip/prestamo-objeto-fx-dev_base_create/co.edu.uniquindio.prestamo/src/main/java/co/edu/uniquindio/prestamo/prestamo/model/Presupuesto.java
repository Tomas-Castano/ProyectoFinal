package co.edu.uniquindio.prestamo.prestamo.model;

import java.util.UUID;

public class Presupuesto {
    private String idPresupuesto;
    private String nombre;
    private double montoAsignado;
    private double montoGastado;
    private Categoria categoriaAsociada;

    public Presupuesto(String nombre, double montoAsignado, Categoria categoriaAsociada) {
        this.idPresupuesto = UUID.randomUUID().toString();
        this.nombre = nombre;
        this.montoAsignado = montoAsignado;
        this.montoGastado = 0.0;
        this.categoriaAsociada = categoriaAsociada;
    }

    public String getIdPresupuesto() {
        return idPresupuesto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getMontoAsignado() {
        return montoAsignado;
    }

    public void setMontoAsignado(double montoAsignado) {
        this.montoAsignado = montoAsignado;
    }

    public double getMontoGastado() {
        return montoGastado;
    }

    public void setMontoGastado(double montoGastado) {
        this.montoGastado = montoGastado;
    }

    public Categoria getCategoriaAsociada() {
        return categoriaAsociada;
    }

    public void setCategoriaAsociada(Categoria categoriaAsociada) {
        this.categoriaAsociada = categoriaAsociada;
    }

    public boolean estaExcedido() {
        return montoGastado > montoAsignado;
    }

    public double porcentajeGastado() {
        return (montoGastado / montoAsignado) * 100;
    }

    @Override
    public String toString() {
        return nombre + " - $" + montoGastado + " / $" + montoAsignado;
    }
}