package co.edu.uniquindio.prestamo.prestamo.service;

import co.edu.uniquindio.prestamo.prestamo.mapping.dto.ClienteDto;
import co.edu.uniquindio.prestamo.prestamo.model.Categoria;
import co.edu.uniquindio.prestamo.prestamo.model.Cliente;
import co.edu.uniquindio.prestamo.prestamo.model.Cuenta;
import co.edu.uniquindio.prestamo.prestamo.model.Transaccion;

import java.util.List;

public interface IModelFactoryService {
    List<ClienteDto> obtenerClientes();

    void registrarTransaccion(Transaccion transaccion);
    void agregarCuenta(Cliente cliente, Cuenta cuenta);
    void actualizarCuenta(Cliente cliente, Cuenta cuenta);
    void eliminarCuenta(Cliente cliente, Cuenta cuenta);
    void actualizarDatosPerfil(Cliente cliente, String nombre, String apellido, String correo, String telefono);

    void crearCategoria(Cliente cliente, Categoria categoriaNueva);
    void actualizarCategoria(Categoria seleccionada, String nombre, String descripcion);
    void eliminarCategoria(Categoria seleccionada);

}
