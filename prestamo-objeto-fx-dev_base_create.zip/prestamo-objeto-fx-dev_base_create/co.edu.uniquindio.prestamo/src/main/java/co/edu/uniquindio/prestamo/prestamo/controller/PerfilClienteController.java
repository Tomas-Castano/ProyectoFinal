package co.edu.uniquindio.prestamo.prestamo.controller;

import co.edu.uniquindio.prestamo.prestamo.factory.ModelFactory;
import co.edu.uniquindio.prestamo.prestamo.model.Cliente;

public class PerfilClienteController {
    ModelFactory modelFactory;
    public PerfilClienteController(){
        modelFactory = ModelFactory.getInstancia();
    }

    public void actualizarPerfil(Cliente cliente, String nombre, String apellido, String correo, String telefono) {
        modelFactory.getBilleteraVirtual().actualizarDatosPerfil(cliente, nombre, apellido, correo, telefono);
    }
}
