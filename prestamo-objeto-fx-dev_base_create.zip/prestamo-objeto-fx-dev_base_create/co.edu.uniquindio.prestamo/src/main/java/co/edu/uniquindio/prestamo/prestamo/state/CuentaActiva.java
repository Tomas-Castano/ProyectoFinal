package co.edu.uniquindio.prestamo.prestamo.state;

import co.edu.uniquindio.prestamo.prestamo.model.Cuenta;
import co.edu.uniquindio.prestamo.prestamo.utils.TipoCuenta;

public class CuentaActiva implements EstadoCuenta {
    @Override
    public void transferir(Cuenta cuenta, double monto, Cuenta destino) {
        if (cuenta.getSaldo() < monto) {
            throw new IllegalArgumentException("Fondos insuficientes para transferir.");
        }
        cuenta.setSaldo(cuenta.getSaldo() - monto);
        destino.recibir(cuenta, monto);
    }

    @Override
    public void recibir(Cuenta cuenta, double monto) {
        cuenta.setSaldo(cuenta.getSaldo() + monto);
    }

    @Override
    public void actualizarInformacion(Cuenta cuenta, String nuevoBanco, TipoCuenta nuevoTipo) {
        cuenta.setNombreBanco(nuevoBanco);
        cuenta.setTipoCuenta(nuevoTipo);
    }
}
