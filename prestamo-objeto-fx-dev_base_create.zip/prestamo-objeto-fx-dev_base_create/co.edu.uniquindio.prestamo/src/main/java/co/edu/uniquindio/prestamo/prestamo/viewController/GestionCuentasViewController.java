package co.edu.uniquindio.prestamo.prestamo.viewController;

import co.edu.uniquindio.prestamo.prestamo.controller.GestionCuentasController;
import co.edu.uniquindio.prestamo.prestamo.factory.ModelFactory;
import co.edu.uniquindio.prestamo.prestamo.model.Cliente;
import co.edu.uniquindio.prestamo.prestamo.model.Cuenta;
import co.edu.uniquindio.prestamo.prestamo.observer.Observer;
import co.edu.uniquindio.prestamo.prestamo.utils.TipoCuenta;
import javafx.beans.property.SimpleStringProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class GestionCuentasViewController implements Observer {
    GestionCuentasController gestionCuentasController = new GestionCuentasController();

    @FXML
    private Button btnActualizar;

    @FXML
    private Button btnAgregarCuenta;

    @FXML
    private Button btnEliminar;

    @FXML
    private ChoiceBox<TipoCuenta> choiceBoxTipoCuentaActualizar;

    @FXML
    private ChoiceBox<TipoCuenta> choiceBoxTipoCuentaAgregar;

    @FXML
    private TableView<Cuenta> tableCuentas;

    @FXML
    private TableColumn<Cuenta, String> tbColumnBanco;

    @FXML
    private TableColumn<Cuenta, String> tbColumnId;

    @FXML
    private TableColumn<Cuenta, String> tbColumnSaldo;

    @FXML
    private TableColumn<Cuenta, String> tbColumnTipoCuenta;

    @FXML
    private TextField txtNombreBanco;

    @FXML
    private TextField txtNombreBanco1;

    @FXML
    private TextField txtId;

    @FXML
    public void initialize() {
        Cliente cliente = (Cliente) ModelFactory.getInstancia().getUsuarioActual();
        initDataBinding(cliente);
        for (Cuenta cuenta : cliente.getListaCuentas()) {
            cuenta.agregarObservador(this);
        }
        choiceBoxTipoCuentaActualizar.getItems().addAll(TipoCuenta.values());
        choiceBoxTipoCuentaAgregar.getItems().addAll(TipoCuenta.values());
    }

    @FXML
    void onActualizarCuenta(ActionEvent event) {
        actualizarCuenta();
    }

    @FXML
    void onAgregarCuenta(ActionEvent event) {
        agregarCuenta();
    }

    @FXML
    void onEliminarCuenta(ActionEvent event) {
        eliminarCuenta();
    }

    private void initDataBinding(Cliente cliente) {
        tbColumnBanco.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getNombreBanco()));
        tbColumnId.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getIdCuenta()));
        tbColumnSaldo.setCellValueFactory(cellData -> new SimpleStringProperty(String.format("$%.2f", cellData.getValue().getSaldo())));
        tbColumnTipoCuenta.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getTipoCuenta().toString()));
        actualizarTabla(cliente);
    }

    private void actualizarTabla(Cliente cliente) {
        tableCuentas.getItems().setAll(cliente.getListaCuentas());
    }

    private void agregarCuenta() {
        String banco = txtNombreBanco1.getText();
        String id = txtId.getText();
        TipoCuenta tipo = choiceBoxTipoCuentaAgregar.getValue();

        if (banco.isEmpty() || id.isEmpty() || tipo == null) {
            mostrarMensaje("Error", "Campos vacíos", "Debe llenar todos los campos", Alert.AlertType.ERROR);
            return;
        }

        Cuenta cuenta = new Cuenta();
        cuenta.setNombreBanco(banco);
        cuenta.setIdCuenta(id);
        cuenta.setTipoCuenta(tipo);
        cuenta.setNumeroCuenta((int)(Math.random() * 1_000_000_000));
        cuenta.setSaldo(0.0);

        try {
            Cliente cliente = (Cliente) ModelFactory.getInstancia().getUsuarioActual();
            GestionCuentasController controller = new GestionCuentasController();
            controller.agregarCuenta(cliente, cuenta);

            mostrarMensaje("Éxito", "Cuenta agregada", "La cuenta se agregó correctamente", Alert.AlertType.INFORMATION);
            limpiarCamposAgregar();
            actualizarTabla(cliente);
        } catch (IllegalArgumentException e) {
            mostrarMensaje("Error", "Cuenta duplicada", e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void eliminarCuenta() {
        Cuenta cuentaSeleccionada = tableCuentas.getSelectionModel().getSelectedItem();
        if (cuentaSeleccionada == null) {
            mostrarMensaje("Error", "Sin selección", "Debes seleccionar una cuenta para eliminar", Alert.AlertType.WARNING);
            return;
        }

        Cliente cliente = (Cliente) ModelFactory.getInstancia().getUsuarioActual();
        GestionCuentasController controller = new GestionCuentasController();
        controller.eliminarCuenta(cliente, cuentaSeleccionada);

        mostrarMensaje("Éxito", "Cuenta eliminada", "La cuenta fue eliminada correctamente", Alert.AlertType.INFORMATION);
        actualizarTabla(cliente);
    }

    private void actualizarCuenta() {
        Cuenta cuentaSeleccionada = tableCuentas.getSelectionModel().getSelectedItem();
        if (cuentaSeleccionada == null) {
            mostrarMensaje("Error", "Sin selección", "Debes seleccionar una cuenta para actualizar", Alert.AlertType.WARNING);
            return;
        }

        String banco = txtNombreBanco.getText();
        TipoCuenta tipo = choiceBoxTipoCuentaActualizar.getValue();

        if (banco.isEmpty() || tipo == null) {
            mostrarMensaje("Error", "Campos vacíos", "Completa los campos para actualizar", Alert.AlertType.ERROR);
            return;
        }

        cuentaSeleccionada.setNombreBanco(banco);
        cuentaSeleccionada.setTipoCuenta(tipo);

        Cliente cliente = (Cliente) ModelFactory.getInstancia().getUsuarioActual();
        gestionCuentasController.actualizarCuenta(cliente, cuentaSeleccionada);

        mostrarMensaje("Éxito", "Cuenta actualizada", "Los datos de la cuenta fueron modificados", Alert.AlertType.INFORMATION);
        actualizarTabla((Cliente) ModelFactory.getInstancia().getUsuarioActual());
    }

    private void mostrarMensaje(String titulo, String header, String contenido, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(titulo);
        alert.setHeaderText(header);
        alert.setContentText(contenido);
        alert.showAndWait();
    }

    private void limpiarCamposAgregar() {
        txtNombreBanco1.clear();
        txtId.clear();
        choiceBoxTipoCuentaAgregar.setValue(null);
    }

    @Override
    public void actualizar() {
        actualizarTabla((Cliente) ModelFactory.getInstancia().getUsuarioActual());
    }
}
