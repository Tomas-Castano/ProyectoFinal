package co.edu.uniquindio.prestamo.prestamo.viewController;

import co.edu.uniquindio.prestamo.prestamo.PrestamoApplication;
import co.edu.uniquindio.prestamo.prestamo.controller.LoginController;
import co.edu.uniquindio.prestamo.prestamo.factory.ModelFactory;
import co.edu.uniquindio.prestamo.prestamo.model.Cliente;
import co.edu.uniquindio.prestamo.prestamo.model.Empleado;
import co.edu.uniquindio.prestamo.prestamo.model.Usuario;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginViewController {
    LoginController loginController = new LoginController();
    ModelFactory modelFactory = ModelFactory.getInstancia();

    @FXML
    private Button btnIniciarSesion;

    @FXML
    private Button btnRegistrarse;

    @FXML
    private TextField txtContraseña;

    @FXML
    private TextField txtUsuario;

    @FXML
    private Pane APcontenedorPrincipal;

    @FXML
    void onIniciarSesion(ActionEvent event) {
        iniciarSesion();
    }

    @FXML
    void onRegistrarse(ActionEvent event) {
        cargarVistaRegistro();
    }

    private void iniciarSesion() {
        String usuario = txtUsuario.getText();
        String contraseña = txtContraseña.getText();

        if (usuario.isEmpty() || contraseña.isEmpty()) {
            mostrarMensaje("Error", "Datos vacíos", "Debe llenar todos los campos", Alert.AlertType.ERROR);
            return;
        }

        Usuario usuarioAutenticado = loginController.verificarCredenciales(usuario, contraseña);

        if (usuarioAutenticado == null) {
            mostrarMensaje("Error", "Credenciales inválidas", "El usuario o contraseña son incorrectos", Alert.AlertType.ERROR);
            return;
        }

        if (usuarioAutenticado instanceof Empleado) {
            ModelFactory.getInstancia().setUsuarioActual(usuarioAutenticado);
            mostrarMensaje("Éxito", "Bienvenido", "Accediste como EMPLEADO", Alert.AlertType.INFORMATION);
            cargarVistaEmpleado();
        } else if (usuarioAutenticado instanceof Cliente) {
            ModelFactory.getInstancia().setUsuarioActual(usuarioAutenticado);
            mostrarMensaje("Éxito", "Bienvenido", "Accediste como CLIENTE", Alert.AlertType.INFORMATION);
            cargarVistaCliente();
        }
    }

    private void mostrarMensaje(String titulo, String header, String contenido, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(titulo);
        alert.setHeaderText(header);
        alert.setContentText(contenido);
        alert.showAndWait();
    }

    private void cargarVistaRegistro() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/co/edu/uniquindio/prestamo/prestamo/Registro.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle("Registro de Cliente");
            stage.setScene(new Scene(root));
            stage.show();

            Stage ventanaActual = (Stage) btnRegistrarse.getScene().getWindow();
            ventanaActual.close();

        } catch (IOException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudo cargar la vista de registro", e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void cargarVistaCliente() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/co/edu/uniquindio/prestamo/prestamo/MainCliente.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle("Billetera virtual!");
            stage.setScene(new Scene(root));
            stage.show();

            Stage ventanaActual = (Stage) btnRegistrarse.getScene().getWindow();
            ventanaActual.close();

        } catch (IOException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudo cargar la vista de registro", e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void cargarVistaEmpleado() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/co/edu/uniquindio/prestamo/prestamo/MainEmpleado.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle("Billetera virtual!");
            stage.setScene(new Scene(root));
            stage.show();

            Stage ventanaActual = (Stage) btnRegistrarse.getScene().getWindow();
            ventanaActual.close();

        } catch (IOException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudo cargar la vista de registro", e.getMessage(), Alert.AlertType.ERROR);
        }
    }
}
