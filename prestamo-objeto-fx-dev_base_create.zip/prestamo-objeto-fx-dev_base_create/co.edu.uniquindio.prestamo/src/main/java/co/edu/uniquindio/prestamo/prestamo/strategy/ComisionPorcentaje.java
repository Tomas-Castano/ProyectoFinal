package co.edu.uniquindio.prestamo.prestamo.strategy;

import co.edu.uniquindio.prestamo.prestamo.model.Transaccion;

public class ComisionPorcentaje implements EstrategiaComision{
    @Override
    public double calcularComision(Transaccion transaccion) {
        return transaccion.getMonto() * 0.01;
    }
}