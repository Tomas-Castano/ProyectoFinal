package co.edu.uniquindio.prestamo.prestamo.controller;

import co.edu.uniquindio.prestamo.prestamo.factory.ModelFactory;
import co.edu.uniquindio.prestamo.prestamo.model.Cuenta;
import co.edu.uniquindio.prestamo.prestamo.model.Transaccion;
import co.edu.uniquindio.prestamo.prestamo.strategy.ComisionFija;
import co.edu.uniquindio.prestamo.prestamo.strategy.ComisionPorcentaje;
import co.edu.uniquindio.prestamo.prestamo.strategy.EstrategiaComision;
import co.edu.uniquindio.prestamo.prestamo.strategy.SinComision;
import co.edu.uniquindio.prestamo.prestamo.utils.TipoCuenta;
import co.edu.uniquindio.prestamo.prestamo.utils.TipoTransaccion;

public class TransaccionController {
    ModelFactory modelFactory;
    public TransaccionController(){
        modelFactory = ModelFactory.getInstancia();
    }

    public void realizarTransaccion(Transaccion transaccion) {
        modelFactory.getBilleteraVirtual().realizarTransaccion(transaccion);
    }

    public static EstrategiaComision seleccionarEstrategia(Transaccion transaccion) {
        Cuenta origen = transaccion.getCuentaOrigen();
        Cuenta destino = transaccion.getCuentaDestino();

        if (transaccion.getTipoTransaccion() == TipoTransaccion.TRANSFERENCIA) {
            if (!origen.getNombreBanco().equalsIgnoreCase(destino.getNombreBanco())) {
                return new ComisionPorcentaje();
            } else {
                return new SinComision();
            }
        }

        if (origen.getTipoCuenta() == TipoCuenta.CORRIENTE) {
            return new ComisionFija();
        }

        return new SinComision();
    }
}
