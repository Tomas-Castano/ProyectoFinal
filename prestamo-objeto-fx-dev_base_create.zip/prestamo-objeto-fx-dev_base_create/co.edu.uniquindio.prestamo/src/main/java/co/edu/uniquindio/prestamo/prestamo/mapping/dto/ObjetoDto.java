package co.edu.uniquindio.prestamo.prestamo.mapping.dto;

public record ObjetoDto(
        String nombre,
        String idObjeto,
        String disponibilidad
) {
}
