package co.edu.uniquindio.prestamo.prestamo.adapter;

import co.edu.uniquindio.prestamo.prestamo.model.Transaccion;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.List;

public class CsvExportadorAdapter implements Exportador {
    @Override
    public void exportar(List<Transaccion> transacciones, File destino) throws Exception {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(destino))) {
            writer.write("Fecha,Descripción,Monto,Tipo,CuentaOrigen,CuentaDestino\n");
            for (Transaccion transaccion : transacciones) {
                writer.write(String.format("%s,%s,%.2f,%s,%s,%s\n",
                        transaccion.getFecha(),
                        transaccion.getDescripcion(),
                        transaccion.getMonto(),
                        transaccion.getTipoTransaccion(),
                        transaccion.getCuentaOrigen().getNumeroCuenta(),
                        transaccion.getCuentaDestino() != null ? transaccion.getCuentaDestino().getNumeroCuenta() : "N/A"
                ));
            }
        }
    }
}
