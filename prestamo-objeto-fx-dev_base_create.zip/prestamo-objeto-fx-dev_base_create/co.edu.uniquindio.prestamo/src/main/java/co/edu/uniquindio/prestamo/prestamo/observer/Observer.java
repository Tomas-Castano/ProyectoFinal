package co.edu.uniquindio.prestamo.prestamo.observer;

public interface Observer {
    void actualizar();
}
