package co.edu.uniquindio.prestamo.prestamo.model;

import java.util.ArrayList;
import java.util.List;

public class Categoria {
    private String idCategoria;
    private String nombreCategoria;
    private String descripcionCategoria;
    public List<Presupuesto> listaPresupuestosAsociados = new ArrayList<>();

    public Categoria(String idCategoria, String nombreCategoria, String descripcionCategoria) {
        this.idCategoria = idCategoria;
        this.nombreCategoria = nombreCategoria;
        this.descripcionCategoria = descripcionCategoria;
    }

    public String getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(String idCategoria) {
        this.idCategoria = idCategoria;
    }

    public String getNombreCategoria() {
        return nombreCategoria;
    }

    public void setNombreCategoria(String nombreCategoria) {
        this.nombreCategoria = nombreCategoria;
    }

    public String getDescripcionCategoria() {
        return descripcionCategoria;
    }

    public void setDescripcionCategoria(String descripcionCategoria) {
        this.descripcionCategoria = descripcionCategoria;
    }

    public List<Presupuesto> getListaPresupuestosAsociados() {
        return listaPresupuestosAsociados;
    }

    public void setListaPresupuestosAsociados(List<Presupuesto> listaPresupuestosAsociados) {
        this.listaPresupuestosAsociados = listaPresupuestosAsociados;
    }

    @Override
    public String toString() {
        return getNombreCategoria() + " | " + getDescripcionCategoria();
    }

    public void agregarPresupuesto(Presupuesto presupuesto) {
        listaPresupuestosAsociados.add(presupuesto);
    }
}
