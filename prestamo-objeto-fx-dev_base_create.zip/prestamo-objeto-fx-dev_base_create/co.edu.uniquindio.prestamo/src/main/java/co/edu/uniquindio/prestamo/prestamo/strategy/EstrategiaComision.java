package co.edu.uniquindio.prestamo.prestamo.strategy;

import co.edu.uniquindio.prestamo.prestamo.model.Transaccion;

public interface EstrategiaComision {
    double calcularComision(Transaccion transaccion);
}
