package co.edu.uniquindio.prestamo.prestamo.viewController;

import javafx.fxml.FXML;

import java.net.URL;
import java.util.ResourceBundle;

public class PrestamoAppController {
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    void initialize() {

    }
}
