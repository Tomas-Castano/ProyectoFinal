package co.edu.uniquindio.prestamo.prestamo.state;

import co.edu.uniquindio.prestamo.prestamo.model.Cuenta;
import co.edu.uniquindio.prestamo.prestamo.utils.TipoCuenta;

public interface EstadoCuenta {
    void transferir(Cuenta cuenta, double monto, Cuenta destino);
    void recibir(Cuenta cuenta, double monto);
    void actualizarInformacion(Cuenta cuenta, String nuevoBanco, TipoCuenta nuevoTipo);
}
