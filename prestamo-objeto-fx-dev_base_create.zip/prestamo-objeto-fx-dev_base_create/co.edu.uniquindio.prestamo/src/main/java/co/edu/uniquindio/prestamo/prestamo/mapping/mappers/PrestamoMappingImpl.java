package co.edu.uniquindio.prestamo.prestamo.mapping.mappers;

import co.edu.uniquindio.prestamo.prestamo.mapping.dto.ClienteDto;
import co.edu.uniquindio.prestamo.prestamo.model.Cliente;
import co.edu.uniquindio.prestamo.prestamo.model.BilleteraVirtual;
import co.edu.uniquindio.prestamo.prestamo.service.IPrestamoMapping;

import java.util.ArrayList;
import java.util.List;

public class PrestamoMappingImpl implements IPrestamoMapping {

    @Override
    public List<ClienteDto> getClientesDto(List<Cliente> listaClientes) {
        if(listaClientes == null){
            return null;
        }
        List<ClienteDto> listaClientesDto = new ArrayList<ClienteDto>(listaClientes.size());
        for (Cliente cliente : listaClientes) {
            listaClientesDto.add(clienteToClienteDto(cliente));
        }

        return listaClientesDto;
    }

    @Override
    public ClienteDto clienteToClienteDto(Cliente cliente) {
        return new ClienteDto(
                cliente.getNombre(),
                cliente.getApellido(),
                cliente.getCedula(),
                cliente.getEmail(),
                cliente.getDireccion());
    }

    @Override
    public Cliente clienteDtoToCliente(ClienteDto clienteDto, int edad, String contraseña) {
        return new Cliente(
                clienteDto.nombre(),
                clienteDto.apellido(),
                clienteDto.cedula(),
                edad,
                contraseña,
                clienteDto.email(),
                null, // teléfono fijo no viene en el DTO
                null, // teléfono celular tampoco
                clienteDto.direccion()
        );
    }

    private BilleteraVirtual mapDisponibilidad(String disponibilidad) {
        if ("Sí".equalsIgnoreCase(disponibilidad)) {
            return null;
        } else {
            return new BilleteraVirtual();
        }
    }

    private String mapPrestamoToDisponibilidad(BilleteraVirtual prestamo) {
        String disponibilidad = "";
        if(prestamo == null){
            disponibilidad = "Si";
        }
        if(prestamo != null){
            disponibilidad = "No";
        }
        return disponibilidad;
    }
}
