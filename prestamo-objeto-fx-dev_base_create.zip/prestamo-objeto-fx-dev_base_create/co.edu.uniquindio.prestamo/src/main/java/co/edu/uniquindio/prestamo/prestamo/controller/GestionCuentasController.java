package co.edu.uniquindio.prestamo.prestamo.controller;

import co.edu.uniquindio.prestamo.prestamo.factory.ModelFactory;
import co.edu.uniquindio.prestamo.prestamo.model.Cliente;
import co.edu.uniquindio.prestamo.prestamo.model.Cuenta;

public class GestionCuentasController {
    ModelFactory modelFactory;
    public GestionCuentasController(){
        modelFactory = ModelFactory.getInstancia();
    }

    public void agregarCuenta(Cliente cliente, Cuenta cuenta) {
        modelFactory.getBilleteraVirtual().agregarCuenta(cliente, cuenta);
    }

    public void actualizarCuenta(Cliente cliente, Cuenta cuenta) {
        modelFactory.getBilleteraVirtual().actualizarCuenta(cliente, cuenta);
    }

    public void eliminarCuenta(Cliente cliente, Cuenta cuenta) {
        modelFactory.getBilleteraVirtual().eliminarCuenta(cliente, cuenta);
    }
}
