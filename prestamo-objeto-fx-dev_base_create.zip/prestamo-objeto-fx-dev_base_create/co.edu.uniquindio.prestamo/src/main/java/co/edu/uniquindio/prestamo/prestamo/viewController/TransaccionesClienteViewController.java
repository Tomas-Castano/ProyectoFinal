package co.edu.uniquindio.prestamo.prestamo.viewController;

import co.edu.uniquindio.prestamo.prestamo.controller.TransaccionController;
import co.edu.uniquindio.prestamo.prestamo.factory.ModelFactory;
import co.edu.uniquindio.prestamo.prestamo.model.Cliente;
import co.edu.uniquindio.prestamo.prestamo.model.Cuenta;
import co.edu.uniquindio.prestamo.prestamo.model.Transaccion;
import co.edu.uniquindio.prestamo.prestamo.strategy.EstrategiaComision;
import co.edu.uniquindio.prestamo.prestamo.utils.TipoTransaccion;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

public class TransaccionesClienteViewController {

    @FXML
    private ChoiceBox<Cuenta> ChoiceBoxCuentaDestino;

    @FXML
    private ChoiceBox<Cuenta> ChoiceBoxCuentaOrigen;

    @FXML
    private ChoiceBox<TipoTransaccion> ChoiceBoxTipoTransaccion;

    @FXML
    private Button btnRealizarTransaccion;

    @FXML
    private TextArea txtFieldDescripcion;

    @FXML
    private TextArea txtFieldHistorial;

    @FXML
    private TextField txtMonto;

    @FXML
    public void initialize() {
        Cliente cliente = (Cliente) ModelFactory.getInstancia().getUsuarioActual();

        ChoiceBoxCuentaOrigen.getItems().addAll(cliente.getListaCuentas());
        ChoiceBoxCuentaDestino.getItems().addAll(cliente.getListaCuentas());
        ChoiceBoxTipoTransaccion.getItems().addAll(TipoTransaccion.values());
    }

    @FXML
    void onRealizarTransaccion(ActionEvent event) {
        realizarTransaccion();
    }

    private void realizarTransaccion() {
        Cliente cliente = (Cliente) ModelFactory.getInstancia().getUsuarioActual();
        try {
            Cuenta origen = ChoiceBoxCuentaOrigen.getValue();
            Cuenta destino = ChoiceBoxCuentaDestino.getValue();
            TipoTransaccion tipo = ChoiceBoxTipoTransaccion.getValue();
            String descripcion = txtFieldDescripcion.getText();
            String montoTexto = txtMonto.getText();

            if (origen == null || tipo == null || montoTexto.isEmpty()) {
                mostrarMensaje("Error", "Campos incompletos", "Seleccione cuenta origen, tipo y monto", Alert.AlertType.ERROR);
                return;
            }

            double monto = Double.parseDouble(montoTexto);
            if (monto <= 0) {
                mostrarMensaje("Error", "Monto inválido", "Ingrese un valor mayor a cero", Alert.AlertType.ERROR);
                return;
            }

            if (tipo == TipoTransaccion.TRANSFERENCIA && destino == null) {
                mostrarMensaje("Error", "Cuenta destino requerida", "Seleccione la cuenta destino para transferencia", Alert.AlertType.ERROR);
                return;
            }

            Transaccion transaccion = new Transaccion();
            transaccion.setCuentaOrigen(origen);
            transaccion.setCuentaDestino(destino);
            transaccion.setTipoTransaccion(tipo);
            transaccion.setMonto(monto);
            transaccion.setDescripcion(descripcion);
            transaccion.setFecha(LocalDate.now());
            transaccion.setIdTransaccion(UUID.randomUUID().toString());

            TransaccionController controller = new TransaccionController();
            EstrategiaComision estrategia = controller.seleccionarEstrategia(transaccion);
            transaccion.setEstrategia(estrategia);

            controller.realizarTransaccion(transaccion);
            actualizarChoiceBoxes();
            cargarHistorialTransacciones();

            double comision = transaccion.getEstrategia().calcularComision(transaccion);
            double total = transaccion.getMonto() + comision;

            mostrarMensaje("Éxito", "Transacción registrada",
                    String.format("Monto: $%.2f\nComisión: $%.2f\nTotal descontado: $%.2f",
                            transaccion.getMonto(), comision, total),
                    Alert.AlertType.INFORMATION);

            limpiarCampos();
        } catch (UnsupportedOperationException e) {
            mostrarMensaje("Cuenta suspendida", "Operación no permitida", "La cuenta de origen está suspendida y no puede realizar transferencias.", Alert.AlertType.WARNING);
        } catch (NumberFormatException e) {
            mostrarMensaje("Error", "Monto inválido", "Debe ingresar un número válido", Alert.AlertType.ERROR);
        } catch (Exception e) {
            mostrarMensaje("Error", "Excepción", e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void cargarHistorialTransacciones() {
        Cliente cliente = (Cliente) ModelFactory.getInstancia().getUsuarioActual();
        if (cliente == null) {
            txtFieldHistorial.setText("No hay cliente logueado.");
            return;
        }

        StringBuilder historial = new StringBuilder();
        List<Transaccion> todas = ModelFactory.getInstancia().getBilleteraVirtual().getListaTransacciones();

        for (Cuenta cuenta : cliente.getListaCuentas()) {
            for (Transaccion transaccion : todas) {
                boolean esOrigen = cuenta.equals(transaccion.getCuentaOrigen());
                boolean esDestino = cuenta.equals(transaccion.getCuentaDestino());

                if (esOrigen || esDestino) {
                    historial.append("📅 Fecha: ").append(transaccion.getFecha()).append("\n")
                            .append("🆔 ID: ").append(transaccion.getIdTransaccion()).append("\n")
                            .append("💵 Monto: $").append(transaccion.getMonto()).append("\n")
                            .append("🔁 Tipo: ").append(transaccion.getTipoTransaccion()).append("\n")
                            .append("📤 Origen: ").append(transaccion.getCuentaOrigen().getNumeroCuenta()).append("\n")
                            .append("📥 Destino: ").append(
                                    transaccion.getCuentaDestino() != null ? transaccion.getCuentaDestino().getNumeroCuenta() : "N/A"
                            ).append("\n")
                            .append("📝 Descripción: ").append(transaccion.getDescripcion()).append("\n")
                            .append("────────────────────────────\n");
                }
            }
        }

        txtFieldHistorial.setText(historial.toString());
    }

    private void mostrarMensaje(String titulo, String header, String contenido, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(titulo);
        alert.setHeaderText(header);
        alert.setContentText(contenido);
        alert.showAndWait();
    }

    private void limpiarCampos() {
        ChoiceBoxCuentaOrigen.setValue(null);
        ChoiceBoxCuentaDestino.setValue(null);
        ChoiceBoxTipoTransaccion.setValue(null);
        txtMonto.clear();
        txtFieldDescripcion.clear();
    }

    public void actualizarChoiceBoxes() {
        Cliente cliente = (Cliente) ModelFactory.getInstancia().getUsuarioActual();

        ChoiceBoxCuentaOrigen.getItems().setAll(cliente.getListaCuentas());
        ChoiceBoxCuentaDestino.getItems().setAll(cliente.getListaCuentas());
    }
}