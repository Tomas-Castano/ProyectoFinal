package co.edu.uniquindio.prestamo.prestamo.utils;

import co.edu.uniquindio.prestamo.prestamo.facade.PresupuestoFacade;
import co.edu.uniquindio.prestamo.prestamo.model.*;
import co.edu.uniquindio.prestamo.prestamo.state.CuentaSuspendida;

import java.util.UUID;

public class DataUtil {

    public static BilleteraVirtual inicializarDatos() {
        BilleteraVirtual billeteraVirtual = new BilleteraVirtual();

        //Empleados
        Empleado Pedro = new Empleado("Pedro", "Gomez","0004", 29, "Pedro123");

        //Clientes
        Cliente Juan = new Cliente("Juan", "Ramirez", "1000", 20, "Juan@gmail.com", null, "0001", "La patria", "Juan123");
        Cliente Ana = new Cliente("Ana", "Gomez", "2000", 31, "Ana@gmail.com", null, "0002", "Genesis", "Ana123");
        Cliente Tobias = new Cliente("Tobias", "Mendoza", "3000", 25, "Tobias@gmail.com", null, "0003", "Las americas", "Tobias123");

        //Cuentas de Juan
        Cuenta bancolombiaJuan = new Cuenta("0001", "Bancolombia", 1, TipoCuenta.AHORRO, 2000);
        Cuenta payPalJuan = new Cuenta("0002", "PayPal", 1, TipoCuenta.AHORRO, 100);
        Cuenta bancoNacionalJuan = new Cuenta("0003", "BancoNacional", 1, TipoCuenta.CORRIENTE, 600);

        //Cuentas de Ana
        Cuenta bancolombiaAna = new Cuenta("0004", "Bancolombia", 1, TipoCuenta.AHORRO, 3000);
        Cuenta payPalAna = new Cuenta("0005", "PayPal", 1, TipoCuenta.CORRIENTE, 600);

        //Cuentas de Tobias
        Cuenta bancolombiaTobias = new Cuenta("0006", "Bancolombia", 1, TipoCuenta.AHORRO, 2500);

        //Categorias de Juan
        Categoria categoriaComidaJuan = new Categoria(UUID.randomUUID().toString(), "Alimentos", "Pa comer bro");

        //Categorias de Ana
        Categoria categoriaComidaAna = new Categoria(UUID.randomUUID().toString(), "Alimentos", "Necesito comer");

        //Categorias de Tobias
        Categoria categoriaVideojuegosTobias = new Categoria(UUID.randomUUID().toString(), "Fondo videojuegos", "Videojuegos tobias");
        Categoria categoriaComidaTobias = new Categoria(UUID.randomUUID().toString(), "Fondo comida", "Comida tobias");

        //Presupuestos de Juan
        Presupuesto presupuesto1Juan = new Presupuesto("Ahorro universidad", 100, null);
        Presupuesto presupuesto2Juan = new Presupuesto("Comida", 200, categoriaComidaJuan);

        //Presupuestos de Ana
        Presupuesto presupuesto1Ana = new Presupuesto("Belleza", 300, null);
        Presupuesto presupuesto2Ana = new Presupuesto("Comida", 400, categoriaComidaAna);

        //Presupuestos de Tobias
        Presupuesto presupuesto1Tobias = new Presupuesto("Videojuegos", 800, categoriaVideojuegosTobias);
        Presupuesto presupuesto2Tobias = new Presupuesto("comida", 600, categoriaComidaTobias);

        bancoNacionalJuan.setEstadoCuenta(new CuentaSuspendida());

        categoriaComidaJuan.agregarPresupuesto(presupuesto2Juan);

        Juan.agregarCuenta(bancolombiaJuan);
        Juan.agregarCuenta(payPalJuan);
        Juan.agregarCuenta(bancoNacionalJuan);
        Juan.agregarCategoria(categoriaComidaJuan);
        Juan.agregarPresupuesto(presupuesto1Juan);
        Juan.agregarPresupuesto(presupuesto2Juan);
        Ana.agregarCuenta(bancolombiaAna);
        Ana.agregarCuenta(payPalAna);
        Ana.agregarCategoria(categoriaComidaAna);
        Ana.agregarPresupuesto(presupuesto1Ana);
        Ana.agregarPresupuesto(presupuesto2Ana);
        Tobias.agregarCuenta(bancolombiaTobias);
        Tobias.agregarCategoria(categoriaVideojuegosTobias);
        Tobias.agregarPresupuesto(presupuesto1Tobias);
        Tobias.agregarPresupuesto(presupuesto2Tobias);
        billeteraVirtual.getListaClientes().add(Juan);
        billeteraVirtual.getListaClientes().add(Ana);
        billeteraVirtual.getListaClientes().add(Tobias);
        billeteraVirtual.getListaEmpleados().add(Pedro);

        return billeteraVirtual;
    }
}
