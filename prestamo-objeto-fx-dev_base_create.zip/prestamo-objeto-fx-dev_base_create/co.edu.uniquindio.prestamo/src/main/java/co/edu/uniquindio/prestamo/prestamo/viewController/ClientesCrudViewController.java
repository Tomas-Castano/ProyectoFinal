package co.edu.uniquindio.prestamo.prestamo.viewController;

import co.edu.uniquindio.prestamo.prestamo.factory.ModelFactory;
import co.edu.uniquindio.prestamo.prestamo.model.Cliente;
import co.edu.uniquindio.prestamo.prestamo.model.Cuenta;
import co.edu.uniquindio.prestamo.prestamo.state.CuentaActiva;
import javafx.beans.property.SimpleStringProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import static co.edu.uniquindio.prestamo.prestamo.factory.ModelFactory.getInstancia;

public class ClientesCrudViewController {
    private final ModelFactory modelFactory = ModelFactory.getInstancia();

    @FXML
    private Button btnActualizar;

    @FXML
    private Button btnAgregar;

    @FXML
    private Button btnEliminar;

    @FXML
    private Button btnNuevo;

    @FXML
    private TableView<Cliente> tableCliente;

    @FXML
    private TableColumn<Cliente, String> tcApellido;

    @FXML
    private TableColumn<Cliente, String> tcCedula;

    @FXML
    private TableColumn<Cliente, String> tcDireccion;

    @FXML
    private TableColumn<Cliente, String> tcEmail;

    @FXML
    private TableColumn<Cliente, String> tcNombre;

    @FXML
    private TextField txtApellido;

    @FXML
    private TextField txtCedula;

    @FXML
    private TextField txtContraseña;

    @FXML
    private TextField txtEmail;

    @FXML
    private TextField txtNombre;

    @FXML
    private TextField txtdireccion;

    @FXML
    public void initialize() {
        initDataBinding();
        cargarClientes();
        tableCliente.getSelectionModel().selectedItemProperty().addListener((obs, old, selected) -> {
            if (selected != null) llenarCampos(selected);
        });
    }

    @FXML
    void onActualizarCliente(ActionEvent event) {
        actualizarCliente();
    }

    @FXML
    void onAgregarCliente(ActionEvent event) {
        agregarCliente();
    }

    @FXML
    void onEliminarCliente(ActionEvent event) {
        eliminarCliente();
    }

    @FXML
    void onNuevoCliente(ActionEvent event) {
        nuevoCliente();
    }

    private void initDataBinding() {
        tcNombre.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getNombre()));
        tcApellido.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getApellido()));
        tcCedula.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getCedula()));
        tcEmail.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getEmail()));
        tcDireccion.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getDireccion()));
    }

    private void cargarClientes() {
        tableCliente.getItems().setAll(modelFactory.getListaClientes());
    }

    private void agregarCliente() {
        String cedula = txtCedula.getText();

        if (cedula.isEmpty() || txtNombre.getText().isEmpty() || txtContraseña.getText().isEmpty()) {
            mostrarMensaje("Error", "Campos obligatorios vacíos", "Completa cédula, nombre y contraseña.", Alert.AlertType.ERROR);
            return;
        }

        for (Cliente cliente : modelFactory.getListaClientes()) {
            if (cliente.getCedula().equals(cedula)) {
                mostrarMensaje("Error", "Duplicado", "Ya existe un cliente con esta cédula.", Alert.AlertType.WARNING);
                return;
            }
        }

        Cliente nuevo = new Cliente(
                txtNombre.getText(), txtApellido.getText(), cedula,
                0, txtEmail.getText(), null, "", txtdireccion.getText(), txtContraseña.getText()
        );

        modelFactory.getListaClientes().add(nuevo);
        cargarClientes();
        limpiarCampos();
        mostrarMensaje("Éxito", "Cliente agregado", "El cliente fue creado correctamente.", Alert.AlertType.INFORMATION);
    }

    void actualizarCliente() {
        Cliente seleccionado = tableCliente.getSelectionModel().getSelectedItem();
        if (seleccionado == null) {
            mostrarMensaje("Error", "Sin selección", "Selecciona un cliente para actualizar", Alert.AlertType.WARNING);
            return;
        }

        seleccionado.setNombre(txtNombre.getText());
        seleccionado.setApellido(txtApellido.getText());
        seleccionado.setEmail(txtEmail.getText());
        seleccionado.setDireccion(txtdireccion.getText());
        seleccionado.setContraseña(txtContraseña.getText());

        cargarClientes();
        limpiarCampos();
        mostrarMensaje("Éxito", "Actualización exitosa", "Los datos del cliente fueron actualizados", Alert.AlertType.INFORMATION);
    }

    private void eliminarCliente() {
        Cliente seleccionado = tableCliente.getSelectionModel().getSelectedItem();
        if (seleccionado == null) {
            mostrarMensaje("Error", "Sin selección", "Selecciona un cliente para eliminar", Alert.AlertType.WARNING);
            return;
        }

        modelFactory.getListaClientes().remove(seleccionado);
        cargarClientes();
        limpiarCampos();
        mostrarMensaje("Éxito", "Cliente eliminado", "El cliente ha sido eliminado del sistema.", Alert.AlertType.INFORMATION);
    }

    private void llenarCampos(Cliente cliente) {
        txtNombre.setText(cliente.getNombre());
        txtApellido.setText(cliente.getApellido());
        txtCedula.setText(cliente.getCedula());
        txtEmail.setText(cliente.getEmail());
        txtdireccion.setText(cliente.getDireccion());
        txtContraseña.setText(cliente.getContraseña());
    }

    private void nuevoCliente() {
        limpiarCampos();
    }

    private void limpiarCampos() {
        txtNombre.clear();
        txtApellido.clear();
        txtCedula.clear();
        txtEmail.clear();
        txtdireccion.clear();
        txtContraseña.clear();
        tableCliente.getSelectionModel().clearSelection();
    }

    private void mostrarMensaje(String titulo, String header, String contenido, Alert.AlertType tipo) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(header);
        alert.setContentText(contenido);
        alert.showAndWait();
    }
}