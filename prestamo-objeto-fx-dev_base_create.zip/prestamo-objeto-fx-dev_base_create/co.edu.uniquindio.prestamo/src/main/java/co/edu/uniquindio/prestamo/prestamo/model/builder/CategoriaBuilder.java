package co.edu.uniquindio.prestamo.prestamo.model.builder;

import co.edu.uniquindio.prestamo.prestamo.model.Categoria;

public class CategoriaBuilder {
    protected String idCategoria;
    protected String nombreCategoria;
    protected String descripcionCategoria;

    public CategoriaBuilder setIdCategoria(String idCategoria) {
        this.idCategoria = idCategoria;
        return this;
    }

    public CategoriaBuilder setNombreCategoria(String nombreCategoria) {
        this.nombreCategoria = nombreCategoria;
        return this;
    }

    public CategoriaBuilder setDescripcionCategoria(String descripcionCategoria) {
        this.descripcionCategoria = descripcionCategoria;
        return this;
    }

    public Categoria build() {
        return new Categoria(idCategoria, nombreCategoria, descripcionCategoria);
    }
}
