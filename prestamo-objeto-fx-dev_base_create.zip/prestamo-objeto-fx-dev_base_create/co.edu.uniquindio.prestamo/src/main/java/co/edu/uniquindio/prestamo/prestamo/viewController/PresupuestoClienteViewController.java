package co.edu.uniquindio.prestamo.prestamo.viewController;

import co.edu.uniquindio.prestamo.prestamo.facade.PresupuestoFacade;
import co.edu.uniquindio.prestamo.prestamo.factory.ModelFactory;
import co.edu.uniquindio.prestamo.prestamo.model.Categoria;
import co.edu.uniquindio.prestamo.prestamo.model.Cliente;
import co.edu.uniquindio.prestamo.prestamo.model.Presupuesto;
import javafx.beans.property.SimpleStringProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class PresupuestoClienteViewController {
    PresupuestoFacade presupuestoFacade = ModelFactory.getInstancia().getPresupuestoFacade();

    @FXML
    private Button btnActualizarPresupuesto;

    @FXML
    private Button btnCrearPresupuesto;

    @FXML
    private Button btnEliminar;

    @FXML
    private ChoiceBox<Categoria> choiceBoxCategoria;

    @FXML
    private TableView<Presupuesto> tableViewPresupuesto;

    @FXML
    private TableColumn<Presupuesto, String> tbColumnNombre;

    @FXML
    private TableColumn<Presupuesto, String> tbColumnMontoRestante;

    @FXML
    private TableColumn<Presupuesto, String> tbColumnMontoGastado;

    @FXML
    private TableColumn<Presupuesto, String> tbColumnMontoPorcentaje;

    @FXML
    private TableColumn<Presupuesto, String> tbColumnEstado;

    @FXML
    private TableColumn<Presupuesto, String> tbColumnCategoria;

    @FXML
    private TableColumn<Presupuesto, String> tbColumnId;

    @FXML
    private TextField txtMontoLimite;

    @FXML
    private TextField txtNombre;

    @FXML
    public void initialize() {
        Cliente cliente = (Cliente) ModelFactory.getInstancia().getUsuarioActual();
        choiceBoxCategoria.getItems().setAll(cliente.getListaCategorias());
        initDataBinding(cliente);
    }

    @FXML
    void onActualizarPresupuesto(ActionEvent event) {
        actualizarPresupuesto();
    }

    @FXML
    void onCrearPresupuesto(ActionEvent event) {
        crearPresupuesto();
    }

    @FXML
    void onEliminarPresupuesto(ActionEvent event) {
        eliminarPresupuesto();
    }

    private void crearPresupuesto() {
        String nombre = txtNombre.getText();
        String montoTexto = txtMontoLimite.getText();
        Categoria categoria = choiceBoxCategoria.getValue(); // puede ser null

        if (nombre.isEmpty() || montoTexto.isEmpty()) {
            mostrarMensaje("Error", "Campos vacíos", "Completa nombre y monto", Alert.AlertType.ERROR);
            return;
        }

        try {
            double montoLimite = Double.parseDouble(montoTexto);
            Cliente cliente = (Cliente) ModelFactory.getInstancia().getUsuarioActual();
            presupuestoFacade.crearPresupuesto(cliente, nombre, montoLimite, categoria); // OK si categoria es null

            mostrarMensaje("Éxito", "Presupuesto creado", "Se ha creado correctamente", Alert.AlertType.INFORMATION);
            actualizarTabla(cliente);
            limpiarCampos();
        } catch (NumberFormatException e) {
            mostrarMensaje("Error", "Monto inválido", "Debe ser un número válido", Alert.AlertType.ERROR);
        }
    }

    private void actualizarPresupuesto() {
        Presupuesto seleccionado = tableViewPresupuesto.getSelectionModel().getSelectedItem();
        if (seleccionado == null) {
            mostrarMensaje("Error", "Ninguno seleccionado", "Seleccione un presupuesto para actualizar", Alert.AlertType.WARNING);
            return;
        }

        String nombre = txtNombre.getText();
        String montoTexto = txtMontoLimite.getText();
        Categoria categoria = choiceBoxCategoria.getValue(); // puede ser null

        if (nombre.isEmpty() || montoTexto.isEmpty()) {
            mostrarMensaje("Error", "Campos vacíos", "Completa nombre y monto", Alert.AlertType.ERROR);
            return;
        }

        try {
            double nuevoLimite = Double.parseDouble(montoTexto);
            Cliente cliente = (Cliente) ModelFactory.getInstancia().getUsuarioActual();
            presupuestoFacade.actualizarPresupuesto(cliente, seleccionado.getIdPresupuesto(), nombre, nuevoLimite, categoria); // se permite null

            mostrarMensaje("Éxito", "Presupuesto actualizado", "Los cambios se guardaron", Alert.AlertType.INFORMATION);
            actualizarTabla(cliente);
            limpiarCampos();
        } catch (NumberFormatException e) {
            mostrarMensaje("Error", "Monto inválido", "Debe ser un número válido", Alert.AlertType.ERROR);
        }
    }

    private void eliminarPresupuesto() {
        Presupuesto seleccionado = tableViewPresupuesto.getSelectionModel().getSelectedItem();
        if (seleccionado == null) {
            mostrarMensaje("Error", "Ninguno seleccionado", "Seleccione un presupuesto para eliminar", Alert.AlertType.WARNING);
            return;
        }

        Cliente cliente = (Cliente) ModelFactory.getInstancia().getUsuarioActual();
        presupuestoFacade.eliminarPresupuesto(cliente, seleccionado.getIdPresupuesto());

        mostrarMensaje("Éxito", "Presupuesto eliminado", "Se eliminó correctamente", Alert.AlertType.INFORMATION);
        actualizarTabla(cliente);
    }

    private void initDataBinding(Cliente cliente) {
        tbColumnNombre.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getNombre()));
        tbColumnMontoRestante.setCellValueFactory(cellData -> {
            Presupuesto p = cellData.getValue();
            double restante = p.getMontoAsignado() - p.getMontoGastado();
            return new SimpleStringProperty(String.format("$%.2f", restante));
        });
        tbColumnMontoGastado.setCellValueFactory(cellData -> new SimpleStringProperty(
                String.format("$%.2f", cellData.getValue().getMontoGastado()))
        );
        tbColumnMontoPorcentaje.setCellValueFactory(cellData -> {
            double porcentaje = (cellData.getValue().getMontoGastado() / cellData.getValue().getMontoAsignado()) * 100;
            return new SimpleStringProperty(String.format("%.2f%%", porcentaje));
        });
        tbColumnEstado.setCellValueFactory(cellData -> {
            boolean excedido = cellData.getValue().getMontoGastado() > cellData.getValue().getMontoAsignado();
            return new SimpleStringProperty(excedido ? "Excedido" : "En control");
        });
        tbColumnCategoria.setCellValueFactory(cellData -> {
            Categoria cat = cellData.getValue().getCategoriaAsociada();
            return new SimpleStringProperty(cat != null ? cat.getNombreCategoria() : "Sin categoría");
        });
        tbColumnId.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getIdPresupuesto()));

        actualizarTabla(cliente);
    }

    private void actualizarTabla(Cliente cliente) {
        tableViewPresupuesto.getItems().setAll(cliente.getListaPresupuestos());
    }

    public void actualizarChoiceBoxCategorias() {
        choiceBoxCategoria.getItems().setAll(ModelFactory.getInstancia().getBilleteraVirtual().getListaCategorias());
    }

    private void mostrarMensaje(String titulo, String header, String contenido, Alert.AlertType tipo) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(header);
        alert.setContentText(contenido);
        alert.showAndWait();
    }

    private void limpiarCampos() {
        txtNombre.clear();
        txtMontoLimite.clear();
        choiceBoxCategoria.setValue(null);
    }
}
