package co.edu.uniquindio.prestamo.prestamo.viewController;

import co.edu.uniquindio.prestamo.prestamo.adapter.CsvExportadorAdapter;
import co.edu.uniquindio.prestamo.prestamo.adapter.Exportador;
import co.edu.uniquindio.prestamo.prestamo.adapter.PdfExportadorAdapter;
import co.edu.uniquindio.prestamo.prestamo.controller.TransaccionController;
import co.edu.uniquindio.prestamo.prestamo.factory.ModelFactory;
import co.edu.uniquindio.prestamo.prestamo.model.Cliente;
import co.edu.uniquindio.prestamo.prestamo.model.Cuenta;
import co.edu.uniquindio.prestamo.prestamo.model.Transaccion;
import co.edu.uniquindio.prestamo.prestamo.model.Usuario;
import co.edu.uniquindio.prestamo.prestamo.strategy.EstrategiaComision;
import co.edu.uniquindio.prestamo.prestamo.utils.TipoTransaccion;
import javafx.beans.property.SimpleStringProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.FileChooser;

import java.io.File;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class GestionTransaccionesViewController {
    @FXML
    private Button btnCrearTransaccion;

    @FXML
    private Button btnExportarCSV;

    @FXML
    private Button btnExportarPDF;

    @FXML
    private ChoiceBox<Cuenta> choiceBoxDestino;

    @FXML
    private ChoiceBox<Cuenta> choiceBoxOrigen;

    @FXML
    private ChoiceBox<TipoTransaccion> choiceBoxTipoTransaccion;

    @FXML
    private ChoiceBox<Usuario> choiceBoxUsuario;

    @FXML
    private TableView<Transaccion> tableViewLista;

    @FXML
    private TableColumn<Transaccion, String> tbColumnDescripcion;

    @FXML
    private TableColumn<Transaccion, String> tbColumnDestino;

    @FXML
    private TableColumn<Transaccion, String> tbColumnFecha;

    @FXML
    private TableColumn<Transaccion, String> tbColumnMonto;

    @FXML
    private TableColumn<Transaccion, String> tbColumnOrigen;

    @FXML
    private TableColumn<Transaccion, String> tbColumnTipo;

    @FXML
    private TextField txtDescripcion;

    @FXML
    private TextField txtMonto;

    @FXML
    public void initialize() {
        initDataBinding();
    }

    @FXML
    void onCrearTransaccion(ActionEvent event) {
        crearTransaccion();
    }

    @FXML
    void onExportarCSV(ActionEvent event) {
        exportarArchivo(new CsvExportadorAdapter(), "csv");
    }

    @FXML
    void onExportarPDF(ActionEvent event) {
        exportarArchivo(new PdfExportadorAdapter(), "pdf");
    }

    private void initDataBinding() {
        List<Usuario> usuarios = new ArrayList<>();
        usuarios.addAll(ModelFactory.getInstancia().getListaClientes());
        usuarios.addAll(ModelFactory.getInstancia().getListaEmpleados());
        choiceBoxUsuario.getItems().addAll(usuarios);

        choiceBoxUsuario.getSelectionModel().selectedItemProperty().addListener((obs, old, nuevoUsuario) -> {
            if (nuevoUsuario instanceof Cliente cliente) {
                choiceBoxOrigen.getItems().setAll(cliente.getListaCuentas());
                choiceBoxDestino.getItems().setAll(cliente.getListaCuentas());
            }
        });

        choiceBoxTipoTransaccion.getItems().addAll(TipoTransaccion.values());

        tbColumnFecha.setCellValueFactory(f -> new SimpleStringProperty(f.getValue().getFecha().toString()));
        tbColumnDescripcion.setCellValueFactory(f -> new SimpleStringProperty(f.getValue().getDescripcion()));
        tbColumnMonto.setCellValueFactory(f -> new SimpleStringProperty(String.format("$%.2f", f.getValue().getMonto())));
        tbColumnTipo.setCellValueFactory(f -> new SimpleStringProperty(f.getValue().getTipoTransaccion().toString()));
        tbColumnOrigen.setCellValueFactory(f -> new SimpleStringProperty(f.getValue().getCuentaOrigen().getNumeroCuenta() + ""));
        tbColumnDestino.setCellValueFactory(f -> {
            Cuenta destino = f.getValue().getCuentaDestino();
            return new SimpleStringProperty(destino != null ? destino.getNumeroCuenta() + "" : "N/A");
        });

        tableViewLista.getItems().setAll(ModelFactory.getInstancia().getBilleteraVirtual().getListaTransacciones());
    }

    private void crearTransaccion() {
        try {
            Cuenta origen = choiceBoxOrigen.getValue();
            Cuenta destino = choiceBoxDestino.getValue();
            TipoTransaccion tipo = choiceBoxTipoTransaccion.getValue();
            double monto = Double.parseDouble(txtMonto.getText());
            String descripcion = txtDescripcion.getText();

            if (origen == null || tipo == null || monto <= 0) {
                mostrarMensaje("Error", "Datos incompletos", "Verifica los campos requeridos.", Alert.AlertType.ERROR);
                return;
            }

            if (tipo == TipoTransaccion.TRANSFERENCIA && destino == null) {
                mostrarMensaje("Error", "Falta cuenta destino", "Seleccione cuenta destino para transferencia.", Alert.AlertType.ERROR);
                return;
            }

            Transaccion transaccion = new Transaccion();
            transaccion.setCuentaOrigen(origen);
            transaccion.setCuentaDestino(destino);
            transaccion.setTipoTransaccion(tipo);
            transaccion.setMonto(monto);
            transaccion.setDescripcion(descripcion);
            transaccion.setFecha(LocalDate.now());
            transaccion.setIdTransaccion(UUID.randomUUID().toString());

            EstrategiaComision estrategia = TransaccionController.seleccionarEstrategia(transaccion);
            transaccion.setEstrategia(estrategia);

            TransaccionController controller = new TransaccionController();
            controller.realizarTransaccion(transaccion);

            tableViewLista.getItems().add(transaccion);
            mostrarMensaje("Éxito", "Transacción creada", "Se realizó correctamente.", Alert.AlertType.INFORMATION);

            txtMonto.clear();
            txtDescripcion.clear();

        } catch (NumberFormatException e) {
            mostrarMensaje("Error", "Monto inválido", "Debe ser un número.", Alert.AlertType.ERROR);
        } catch (Exception e) {
            mostrarMensaje("Error", "Error inesperado", e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void exportarArchivo(Exportador exportador, String extension) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter(extension.toUpperCase(), "*." + extension.toLowerCase()));
        File archivo = fileChooser.showSaveDialog(null);

        if (archivo != null) {
            try {
                exportador.exportar(tableViewLista.getItems(), archivo);
                mostrarMensaje("Éxito", "Archivo exportado", "Se exportó correctamente.", Alert.AlertType.INFORMATION);
            } catch (Exception e) {
                mostrarMensaje("Error", "No se pudo exportar", e.getMessage(), Alert.AlertType.ERROR);
            }
        }
    }

    private void mostrarMensaje(String titulo, String header, String contenido, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(titulo);
        alert.setHeaderText(header);
        alert.setContentText(contenido);
        alert.showAndWait();
    }
}