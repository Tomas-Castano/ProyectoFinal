package co.edu.uniquindio.prestamo.prestamo.controller;

import co.edu.uniquindio.prestamo.prestamo.factory.ModelFactory;
import co.edu.uniquindio.prestamo.prestamo.model.Usuario;

public class LoginController {
    ModelFactory modelFactory;
    public LoginController(){
        modelFactory = ModelFactory.getInstancia();
    }

    public Usuario verificarCredenciales(String nombre, String contraseña) {
        return ModelFactory.verificarCredenciales(nombre, contraseña);
    }
}
