package co.edu.uniquindio.prestamo.prestamo.viewController;

import co.edu.uniquindio.prestamo.prestamo.factory.ModelFactory;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;

public class MainEmpleadoViewController {
    private EstadisticasViewController estadisticasVC;

    @FXML
    private Button btnCerrarSesion;

    @FXML
    private Tab tabEstadisticas;

    @FXML
    private Tab tabGestionCuentas;

    @FXML
    private Tab tabGestionTransacciones;

    @FXML
    private Tab tabGestionUsuarios;

    @FXML
    private TabPane tabPaneMainEmpleado;

    @FXML
    public void initialize() {
        cargarTabs();

        tabPaneMainEmpleado.getSelectionModel().selectedItemProperty().addListener((obs, oldTab, newTab) -> {
            if (newTab == tabEstadisticas && estadisticasVC != null) {
                estadisticasVC.actualizarEstadisticas();
            }
        });
    }

    @FXML
    void onCerrarSesion(ActionEvent event) {
        cerrarSesion();
    }

    private void cerrarSesion() {
        ModelFactory.getInstancia().setUsuarioActual(null);
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/co/edu/uniquindio/prestamo/prestamo/Login.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle("Inicio de sesión");
            stage.setScene(new Scene(root));
            stage.show();

            Stage ventanaActual = (Stage) btnCerrarSesion.getScene().getWindow();
            ventanaActual.close();

        } catch (IOException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudo cargar la vista de login", e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void cargarTabs() {
        try {
            FXMLLoader loaderEstadisticas = new FXMLLoader(getClass().getResource("/co/edu/uniquindio/prestamo/prestamo/Estadisticas.fxml"));
            AnchorPane vistaEstadisticas = loaderEstadisticas.load();
            estadisticasVC = loaderEstadisticas.getController();
            tabEstadisticas.setContent(vistaEstadisticas);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void mostrarMensaje(String titulo, String header, String contenido, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(titulo);
        alert.setHeaderText(header);
        alert.setContentText(contenido);
        alert.showAndWait();
    }
}