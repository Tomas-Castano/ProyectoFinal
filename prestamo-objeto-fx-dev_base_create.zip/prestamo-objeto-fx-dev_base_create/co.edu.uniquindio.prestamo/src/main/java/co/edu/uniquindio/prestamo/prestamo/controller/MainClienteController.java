package co.edu.uniquindio.prestamo.prestamo.controller;

import co.edu.uniquindio.prestamo.prestamo.factory.ModelFactory;

public class MainClienteController {
    ModelFactory modelFactory;
    public MainClienteController(){
        modelFactory = ModelFactory.getInstancia();
    }
}
