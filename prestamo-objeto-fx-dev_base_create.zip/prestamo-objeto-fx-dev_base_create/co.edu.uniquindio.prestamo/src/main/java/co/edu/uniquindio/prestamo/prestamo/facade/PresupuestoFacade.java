package co.edu.uniquindio.prestamo.prestamo.facade;

import co.edu.uniquindio.prestamo.prestamo.factory.ModelFactory;
import co.edu.uniquindio.prestamo.prestamo.model.*;

import java.util.UUID;

public class PresupuestoFacade {

    private final BilleteraVirtual sistema;

    public PresupuestoFacade(BilleteraVirtual sistema) {
        this.sistema = sistema;
    }

    public void crearPresupuesto(Cliente cliente, String nombre, double monto, Categoria categoria) {
        String id = UUID.randomUUID().toString();
        Presupuesto presupuesto = new Presupuesto(nombre, monto, categoria);
        cliente.getListaPresupuestos().add(presupuesto);
    }

    public void eliminarPresupuesto(Cliente cliente, String idPresupuesto) {
        cliente.getListaPresupuestos().removeIf(p -> p.getIdPresupuesto().equals(idPresupuesto));
    }

    public void actualizarPresupuesto(Cliente cliente, String idPresupuesto, String nuevoNombre, double nuevoMonto, Categoria nuevaCategoria) {
        for (Presupuesto p : cliente.getListaPresupuestos()) {
            if (p.getIdPresupuesto().equals(idPresupuesto)) {
                p.setNombre(nuevoNombre);
                p.setMontoAsignado(nuevoMonto);
                p.setCategoriaAsociada(nuevaCategoria);
                break;
            }
        }
    }

    public double calcularGastoEnCategoria(Cliente cliente, Categoria categoria) {
        double total = 0.0;

        for (Transaccion transaccion : sistema.getListaTransacciones()) {
            if (transaccion.getCuentaOrigen() != null &&
                    cliente.getListaCuentas().contains(transaccion.getCuentaOrigen()) &&
                    transaccion.getCategoria() != null &&
                    transaccion.getCategoria().equals(categoria)) {

                total += transaccion.getMonto();
            }
        }

        return total;
    }
}
