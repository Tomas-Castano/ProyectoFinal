package co.edu.uniquindio.prestamo.prestamo.viewController;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.AnchorPane;

import java.io.IOException;

public class MainClienteViewController {
    private TransaccionesClienteViewController transaccionesClienteVC;
    private PresupuestoClienteViewController presupuestoClienteVC;

    @FXML
    private TabPane tabPane;

    @FXML
    private Tab tabTransacciones;

    @FXML
    private Tab tabPresupuesto;

    @FXML
    public void initialize() {
        cargarTabs();
        tabPane.getSelectionModel().selectedItemProperty().addListener((obs, oldTab, newTab) -> {
            if (newTab == tabTransacciones && transaccionesClienteVC != null) {
                transaccionesClienteVC.actualizarChoiceBoxes();
            }
        });
        tabPane.getSelectionModel().selectedItemProperty().addListener((obs, oldTab, newTab) -> {
            if (newTab == tabPresupuesto && presupuestoClienteVC != null) {
                presupuestoClienteVC.actualizarChoiceBoxCategorias();
            }
        });
    }

    private void cargarTabs() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/co/edu/uniquindio/prestamo/prestamo/TransaccionesCliente.fxml"));
            AnchorPane vistaTransacciones = loader.load();
            transaccionesClienteVC = loader.getController();
            tabTransacciones.setContent(vistaTransacciones);


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}