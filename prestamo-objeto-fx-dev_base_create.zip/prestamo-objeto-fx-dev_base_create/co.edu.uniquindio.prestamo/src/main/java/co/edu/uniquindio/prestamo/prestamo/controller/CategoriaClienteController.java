package co.edu.uniquindio.prestamo.prestamo.controller;

import co.edu.uniquindio.prestamo.prestamo.factory.ModelFactory;
import co.edu.uniquindio.prestamo.prestamo.model.Categoria;
import co.edu.uniquindio.prestamo.prestamo.model.Cliente;

public class CategoriaClienteController {
    ModelFactory modelFactory;
    public CategoriaClienteController(){
        modelFactory = ModelFactory.getInstancia();
    }

    public void crearCategoria(Cliente cliente, Categoria categoriaNueva) {
        modelFactory.crearCategoria(cliente, categoriaNueva);
    }

    public void actualizarCategoria(Categoria seleccionada, String nombre, String descripcion) {
        modelFactory.actualizarCategoria(seleccionada, nombre, descripcion);
    }

    public void eliminarCategoria(Categoria seleccionada) {
        modelFactory.eliminarCategoria(seleccionada);
    }
}
