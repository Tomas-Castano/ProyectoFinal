package co.edu.uniquindio.prestamo.prestamo.viewController;

import co.edu.uniquindio.prestamo.prestamo.factory.ModelFactory;
import co.edu.uniquindio.prestamo.prestamo.model.Cliente;
import co.edu.uniquindio.prestamo.prestamo.model.Cuenta;
import co.edu.uniquindio.prestamo.prestamo.state.CuentaActiva;
import co.edu.uniquindio.prestamo.prestamo.state.EstadoCuenta;
import co.edu.uniquindio.prestamo.prestamo.utils.TipoCuenta;
import javafx.beans.property.SimpleStringProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class GestionCuentasEmpleadoViewController {

    @FXML
    private Button btnActualizarCuenta;

    @FXML
    private Button btnAgregarCuenta;

    @FXML
    private Button btnCambiarEstadoCuenta;

    @FXML
    private ChoiceBox<TipoCuenta> choiceBoxTipoCuenta;

    @FXML
    private ChoiceBox<Cliente> choiceBoxUsuario;

    @FXML
    private TableView<Cuenta> tableViewCuenta;

    @FXML
    private TableColumn<Cuenta, String> tbColumnEstadoCuenta;

    @FXML
    private TableColumn<Cuenta, String> tbColumnId;

    @FXML
    private TableColumn<Cuenta, String> tbColumnNombreBanco;

    @FXML
    private TableColumn<Cuenta, String> tbColumnSaldo;

    @FXML
    private TableColumn<Cuenta, String> tbColumnTipoCuenta;

    @FXML
    private TextField txtId;

    @FXML
    private TextField txtNombreBanco;

    @FXML
    public void initialize() {
        choiceBoxUsuario.getItems().setAll(ModelFactory.getInstancia().getBilleteraVirtual().getListaClientes());
        choiceBoxTipoCuenta.getItems().setAll(TipoCuenta.values());
        choiceBoxUsuario.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                actualizarTabla(newVal);
            }
        });

        initDataBinding();
    }

    @FXML
    void onActualizarCuenta(ActionEvent event) {
        actualizarCuenta();
    }

    @FXML
    void onAgregarCuenta(ActionEvent event) {
        agregarCuenta();
    }

    @FXML
    void onCambiarEstadoCuenta(ActionEvent event) {
        cambiarEstadoCuenta();
    }

    private void initDataBinding() {
        tbColumnId.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getIdCuenta()));
        tbColumnNombreBanco.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getNombreBanco()));
        tbColumnTipoCuenta.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getTipoCuenta().toString()));
        tbColumnSaldo.setCellValueFactory(cellData -> new SimpleStringProperty(String.format("$%.2f", cellData.getValue().getSaldo())));
        tbColumnEstadoCuenta.setCellValueFactory(cellData -> {
            EstadoCuenta estado = cellData.getValue().getEstadoCuenta();
            String estadoStr = (estado instanceof CuentaActiva) ? "Activa" : "Suspendida";
            return new SimpleStringProperty(estadoStr);
        });
    }

    private void agregarCuenta() {
        Cliente cliente = choiceBoxUsuario.getValue();
        if (cliente == null) {
            mostrarAlerta("Debe seleccionar un usuario.");
            return;
        }

        String banco = txtNombreBanco.getText();
        String id = txtId.getText();
        TipoCuenta tipo = choiceBoxTipoCuenta.getValue();

        if (banco.isEmpty() || id.isEmpty() || tipo == null) {
            mostrarAlerta("Todos los campos son obligatorios.");
            return;
        }

        Cuenta nueva = new Cuenta();
        nueva.setNombreBanco(banco);
        nueva.setIdCuenta(id);
        nueva.setTipoCuenta(tipo);
        nueva.setNumeroCuenta((int)(Math.random() * 1_000_000_000));
        nueva.setSaldo(0.0);

        try {
            ModelFactory.getInstancia().getBilleteraVirtual().agregarCuenta(cliente, nueva);
            actualizarTabla(cliente);
            mostrarInfo("Cuenta agregada exitosamente.");
        } catch (IllegalArgumentException e) {
            mostrarAlerta(e.getMessage());
        }
    }

    private void actualizarCuenta() {
        Cuenta seleccionada = tableViewCuenta.getSelectionModel().getSelectedItem();
        Cliente cliente = choiceBoxUsuario.getValue();
        if (seleccionada == null || cliente == null) {
            mostrarAlerta("Debe seleccionar un cliente y una cuenta.");
            return;
        }

        String nuevoBanco = txtNombreBanco.getText();
        TipoCuenta nuevoTipo = choiceBoxTipoCuenta.getValue();

        if (nuevoBanco.isEmpty() || nuevoTipo == null) {
            mostrarAlerta("Debe completar los campos.");
            return;
        }

        seleccionada.actualizarInformacion(nuevoBanco, nuevoTipo);
        ModelFactory.getInstancia().getBilleteraVirtual().actualizarCuenta(cliente, seleccionada);
        actualizarTabla(cliente);
        mostrarInfo("Cuenta actualizada.");
    }

    private void cambiarEstadoCuenta() {
        Cuenta cuenta = tableViewCuenta.getSelectionModel().getSelectedItem();
        Cliente cliente = choiceBoxUsuario.getValue();
        if (cuenta == null || cliente == null) {
            mostrarAlerta("Seleccione una cuenta.");
            return;
        }

        cuenta.cambiarEstadoCuenta();
        actualizarTabla(cliente);
        mostrarInfo("Estado cambiado.");
    }

    private void mostrarAlerta(String mensaje) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    private void mostrarInfo(String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    private void actualizarTabla(Cliente cliente) {
        tableViewCuenta.getItems().setAll(cliente.getListaCuentas());
    }
}
