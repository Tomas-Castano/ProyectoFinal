package co.edu.uniquindio.prestamo.prestamo.controller;

import co.edu.uniquindio.prestamo.prestamo.factory.ModelFactory;

public class RegistroController {
    ModelFactory modelFactory;
    public RegistroController(){
        modelFactory = ModelFactory.getInstancia();
    }


}
