package co.edu.uniquindio.prestamo.prestamo.controller;

import co.edu.uniquindio.prestamo.prestamo.factory.ModelFactory;

public class GestionTransaccionesController {
    ModelFactory modelFactory;
    public GestionTransaccionesController(){
        modelFactory = ModelFactory.getInstancia();
    }
}
