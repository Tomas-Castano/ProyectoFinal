package co.edu.uniquindio.prestamo.prestamo.adapter;

import co.edu.uniquindio.prestamo.prestamo.model.Transaccion;

import java.io.File;
import java.util.List;

public interface Exportador {
    void exportar(List<Transaccion> transacciones, File destino) throws Exception;
}
