package co.edu.uniquindio.prestamo.prestamo.factory;

import co.edu.uniquindio.prestamo.prestamo.facade.PresupuestoFacade;
import co.edu.uniquindio.prestamo.prestamo.mapping.dto.ClienteDto;
import co.edu.uniquindio.prestamo.prestamo.mapping.mappers.PrestamoMappingImpl;
import co.edu.uniquindio.prestamo.prestamo.model.*;
import co.edu.uniquindio.prestamo.prestamo.service.IModelFactoryService;
import co.edu.uniquindio.prestamo.prestamo.service.IPrestamoMapping;
import co.edu.uniquindio.prestamo.prestamo.utils.DataUtil;

import java.util.Collection;
import java.util.List;

public class ModelFactory implements IModelFactoryService {
    private static ModelFactory modelFactory;
    private static BilleteraVirtual billeteraVirtual = new BilleteraVirtual();
    private final PresupuestoFacade presupuestoFacade;
    private IPrestamoMapping mapper;
    private Usuario usuarioActual;

    public static ModelFactory getInstancia() {
        if(modelFactory == null) {
            modelFactory = new ModelFactory();
        }
        return modelFactory;
    }

    private ModelFactory(){
        mapper = new PrestamoMappingImpl();
        billeteraVirtual = DataUtil.inicializarDatos();
        presupuestoFacade = new PresupuestoFacade(billeteraVirtual);
    }

    public static BilleteraVirtual getBilleteraVirtual() {
        return billeteraVirtual;
    }

    public static void setBilleteraVirtual(BilleteraVirtual billeteraVirtual) {
        ModelFactory.billeteraVirtual = billeteraVirtual;
    }

    public Usuario getUsuarioActual() {
        return usuarioActual;
    }

    public void setUsuarioActual(Usuario usuarioActual) {
        this.usuarioActual = usuarioActual;
    }

    @Override
    public List<ClienteDto> obtenerClientes() {
        return mapper.getClientesDto(billeteraVirtual.getListaClientes());
    }

    @Override
    public void registrarTransaccion(Transaccion transaccion) {
        billeteraVirtual.registrarTransaccion(transaccion);
    }

    @Override
    public void agregarCuenta(Cliente cliente, Cuenta cuenta) {
        getBilleteraVirtual().agregarCuenta(cliente, cuenta);
    }

    @Override
    public void actualizarCuenta(Cliente cliente, Cuenta cuenta) {
        getBilleteraVirtual().actualizarCuenta(cliente, cuenta);
    }

    @Override
    public void eliminarCuenta(Cliente cliente, Cuenta cuenta) {
        getBilleteraVirtual().eliminarCuenta(cliente, cuenta);
    }

    @Override
    public void actualizarDatosPerfil(Cliente cliente, String nombre, String apellido, String correo, String telefono) {

    }

    @Override
    public void crearCategoria(Cliente cliente, Categoria categoriaNueva) {
        billeteraVirtual.crearCategoria(cliente, categoriaNueva);
    }

    @Override
    public void actualizarCategoria(Categoria seleccionada, String nombre, String descripcion) {
        billeteraVirtual.actualizarCategoria(seleccionada, nombre, descripcion);
    }

    @Override
    public void eliminarCategoria(Categoria seleccionada) {
        billeteraVirtual.eliminarCategoria(seleccionada);
    }

    public static Usuario verificarCredenciales(String nombre, String contraseña) {
        return billeteraVirtual.verificarCredenciales(nombre, contraseña);
    }

    public Collection<Cliente> getListaClientes() {
        return billeteraVirtual.getListaClientes();
    }

    public Collection<Empleado> getListaEmpleados() {
        return billeteraVirtual.getListaEmpleados();
    }

    public List<Categoria> getListaCategorias() {
        return billeteraVirtual.getListaCategorias();
    }

    public PresupuestoFacade getPresupuestoFacade() {
        return presupuestoFacade;
    }
}
