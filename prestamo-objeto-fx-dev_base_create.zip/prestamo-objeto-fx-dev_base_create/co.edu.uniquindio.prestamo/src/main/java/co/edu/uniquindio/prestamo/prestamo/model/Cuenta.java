package co.edu.uniquindio.prestamo.prestamo.model;

import co.edu.uniquindio.prestamo.prestamo.observer.Observable;
import co.edu.uniquindio.prestamo.prestamo.observer.Observer;
import co.edu.uniquindio.prestamo.prestamo.state.CuentaActiva;
import co.edu.uniquindio.prestamo.prestamo.state.CuentaSuspendida;
import co.edu.uniquindio.prestamo.prestamo.state.EstadoCuenta;
import co.edu.uniquindio.prestamo.prestamo.utils.TipoCuenta;

import java.util.ArrayList;
import java.util.List;

public class Cuenta implements Observable {
    private String idCuenta;
    private String nombreBanco;
    private int numeroCuenta;
    TipoCuenta tipoCuenta;
    private double saldo;
    private EstadoCuenta estadoDeCuenta;

    private final List<Observer> observadores = new ArrayList<>();

    public Cuenta() {}

    public Cuenta(String idCuenta, String nombreBanco, int numeroCuenta, TipoCuenta tipoCuenta, double saldo) {
        this.idCuenta = idCuenta;
        this.nombreBanco = nombreBanco;
        this.numeroCuenta = numeroCuenta;
        this.tipoCuenta = tipoCuenta;
        this.saldo = saldo;
        this.estadoCuenta = new CuentaActiva();
    }

    private EstadoCuenta estadoCuenta = new CuentaActiva();

    public String getIdCuenta() {
        return idCuenta;
    }

    public void setIdCuenta(String idCuenta) {
        this.idCuenta = idCuenta;
    }

    public String getNombreBanco() {
        return nombreBanco;
    }

    public void setNombreBanco(String nombreBanco) {
        this.nombreBanco = nombreBanco;
    }

    public int getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(int numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public TipoCuenta getTipoCuenta() {
        return tipoCuenta;
    }

    public void setTipoCuenta(TipoCuenta tipoCuenta) {
        this.tipoCuenta = tipoCuenta;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
        notificarObservadores();
    }

    public EstadoCuenta getEstadoDeCuenta() {
        return estadoDeCuenta;
    }

    public void setEstadoDeCuenta(EstadoCuenta estadoDeCuenta) {
        this.estadoDeCuenta = estadoDeCuenta;
    }

    public List<Observer> getObservadores() {
        return observadores;
    }

    public EstadoCuenta getEstadoCuenta() {
        return estadoCuenta;
    }

    public void setEstadoCuenta(EstadoCuenta estadoCuenta) {
        this.estadoCuenta = estadoCuenta;
    }

    @Override
    public String toString() {
        return "Banco: " + nombreBanco +
                " | Id: " + idCuenta +
                " | Tipo de cuenta: " + tipoCuenta +
                " | Número de la cuenta: " + numeroCuenta +
                " | Saldo: $" + String.format("%.2f", saldo);
    }

    @Override
    public void agregarObservador(Observer observer) {
        observadores.add(observer);
    }

    @Override
    public void eliminarObservador(Observer observer) {
        observadores.remove(observer);
    }

    @Override
    public void notificarObservadores() {
        for (Observer observer : observadores) {
            observer.actualizar();
        }
    }

    public void transferir(double monto, Cuenta destino) {
        estadoCuenta.transferir(this, monto, destino);
    }

    public void recibir(Cuenta origen, double monto) {
        estadoCuenta.recibir(this, monto);
    }

    public void actualizarInformacion(String banco, TipoCuenta tipo) {
        estadoCuenta.actualizarInformacion(this, banco, tipo);
    }

    public void cambiarEstadoCuenta() {
        if (estadoCuenta instanceof CuentaActiva) {
            this.estadoCuenta = new CuentaSuspendida();
        } else {
            this.estadoCuenta = new CuentaActiva();
        }
        notificarObservadores();
    }
}
