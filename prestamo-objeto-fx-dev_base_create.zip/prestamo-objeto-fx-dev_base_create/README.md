# prestamo-objeto-fx
proyecto de prestamo 2025-1
